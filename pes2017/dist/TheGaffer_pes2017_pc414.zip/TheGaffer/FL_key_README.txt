FL_key.bin = save key for Football Life 2027 (provided by the SP Football Life team).
The Gaffer needs it only to open FL27 saves. Leave it next to server.py. FL26 / PES 2021 saves do not use it.
