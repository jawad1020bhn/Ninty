Regen fix for Football Life 26 by mataodzanata (FL Mod Studio) (included with his permission).
Regens become new players: new name, new potential, and a generic or face-pack face instead of the retired player's.
Install it from the app: Setup > Regen fix > Install. The app copies the files into Sider\modules and livecpk and adds the lines to sider.ini (with a backup).
All credit to mataodzanata (FL Mod Studio).
