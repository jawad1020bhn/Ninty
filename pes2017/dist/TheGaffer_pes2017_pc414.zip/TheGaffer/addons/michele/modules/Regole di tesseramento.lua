-- Regole di tesseramento.lua   --   v1.5   (Michele e Claude, 12 ottobre 2026)
-- Mod per Football Life 2026 (Sider). Licenza libera, con citazione.
--
-- COSA FA
-- Mette in Master League le regole di tesseramento dei campionati veri, per
-- TE e per la CPU. Un acquisto che le viola non si fa: alla CPU il
-- trasferimento salta, a te il gioco risponde come quando la rosa e' piena.
-- Vendere e' sempre possibile. I ragazzi fino a 21 anni sono sempre liberi.
--
--   Serie A    25 giocatori sopra i 21 anni; massimo 2 extracomunitari
--              nuovi dall'estero per finestra di mercato
--   Serie B    25 sopra i 21; 1 extracomunitario nuovo dall'estero
--   Serie C    25 sopra i 21; nessun extracomunitario nuovo dall'estero
--   LaLiga e
--   LaLiga 2   25 sopra i 21; massimo 3 extracomunitari in rosa
--   Ligue 1 e
--   Ligue 2    massimo 4 extracomunitari in rosa
--   Premier    25 sopra i 21
--   (gli altri campionati: nessuna regola)
-- Comunitari: Unione Europea, Svizzera, Norvegia, Islanda, Liechtenstein.
-- Inglesi, scozzesi, gallesi e nordirlandesi contano come extracomunitari.
-- Il gioco conosce una sola nazionalita' per giocatore: i doppi passaporti
-- non li vede. Per questo in Spagna e Francia, dove le rose del database
-- hanno gia' piu' extracomunitari del tetto, chi e' gia' sopra a inizio
-- finestra puo' solo sostituire: per prenderne uno ne deve cedere uno.
-- "Dall'estero" vuol dire da un club non italiano (o da svincolato).
-- La serie di ogni club la legge dal gioco: con promozioni e retrocessioni
-- le regole seguono il club.
--
-- COME (per chi vuole controllare)
--   0x140F2CFA0  la funzione di Konami che fa un trasferimento fra club CPU:
--                se l'acquisto viola le regole risponde "no" subito.
--   0x140EE5C6C  il controllo delle tue trattative (offerta e firma):
--                se l'acquisto viola le regole il codice diventa 3.
-- Prima di scrivere controlla che i byte siano quelli originali: con
-- un'altra versione del gioco non tocca niente. Non tocca l'eseguibile su
-- disco, ne' il salvataggio, ne' il database.
--
-- FILE in SiderAddons:
--   "Regole di tesseramento - finestra.txt"  i conti della finestra in corso
--                                            (cosi' sopravvivono al caricamento)
--   "Regole di tesseramento - diario.txt"    gli acquisti bloccati
-- In sider.ini va DOPO "Economia Lunga - motore.lua".

local m = { version = "1.9-gaffer1" }   -- The Gaffer pc196: tabella squadre trovata da sola (vedi trova_tabella)
-- v1.9 (12/10/2026): nel diario ogni blocco una volta sola per giorno (il
-- gioco controlla due volte ogni tentativo e lo ritenta: c'erano doppioni).
-- v1.8 (12/10/2026): IL CARATTERE DEI CLUB NEGLI ACQUISTI DELLA CPU. Alla
-- stessa porta dei trasferimenti della CPU, dopo le regole, un club con un
-- carattere ("Identita dei Club" 1.5) compra solo giocatori adatti a lui:
-- GRANDE campioni 78+ o talenti fino a 21 anni 72+, VIVAIO fino a 24 anni,
-- ESPERIENZA dai 27 anni o campioni 80+. Un giocatore fuori stile su cinque
-- passa lo stesso (fisso per tutta la finestra). Nel diario: "fuori dal
-- carattere del club". Le tue trattative non c'entrano.
-- v1.7 (12/10/2026): tolta la diagnosi. Prova completa alla Pro Vercelli
-- (Serie C): Dzeko, Itakura, Tsuchiya e Hatanaka bloccati (extracomunitari
-- da club stranieri), Vardy, Pedro, Giroud, Modric passano. Con il motore
-- 1.21 la regola e' attiva subito dopo il caricamento, senza "Avanti", e con
-- Frasi del mercato 1.3 il messaggio e' quello del regolamento.
-- v1.6 (12/10/2026): DIAGNOSI TEMPORANEA. Alla Pro Vercelli il gioco blocca
-- offerte e firme con "rosa troppo grande (40)" anche con 27 giocatori, e il
-- diario non mostra blocchi nostri. Ora il codice segna ogni controllo delle
-- tue trattative (codice di Konami prima e dopo di noi, modo, squadra,
-- giocatore) e il diario lo scrive come "VERIFICA". Da togliere dopo.
-- v1.5 (12/10/2026): il codice segna il motivo dell'ultimo blocco delle tue
-- trattative (1 lista dei 25, 2 extracomunitari): con "Frasi del mercato" il
-- gioco scrive il motivo vero invece di "rosa troppo grande".
-- v1.4 (12/10/2026): prima prova in partita (Lecco, Serie C): i giapponesi
-- Omori e Fujita bloccati sia all'offerta sia alla firma; la CPU bloccata il
-- primo giorno (Nancy, Castellon, Chievo). Tolta la diagnosi.
-- v1.3: il blocco del motore e' un puntatore nativo: va convertito in numero
-- prima di scriverlo nel codice (con la v1.0-1.2 le regole non partivano).

local REGOLE = {
    [18]  = { nome = "Serie A",        lista = 25, nuovi_extra = 2 },
    [82]  = { nome = "Serie B",        lista = 25, nuovi_extra = 1 },
    [74]  = { nome = "Serie C",        lista = 25, nuovi_extra = 0 },
    [19]  = { nome = "LaLiga",         lista = 25, extra_in_rosa = 3 },
    [80]  = { nome = "LaLiga 2",       lista = 25, extra_in_rosa = 3 },
    [116] = { nome = "Ligue 1",        extra_in_rosa = 4 },
    [62]  = { nome = "Ligue 2",        extra_in_rosa = 4 },
    [17]  = { nome = "Premier League", lista = 25 },
}
local ITALIA = { [18] = true, [82] = true, [74] = true }
local ETA_LIBERA = 21
local COMUNITARI = { 194, 197, 199, 200, 201, 202, 203, 205, 207, 208, 210, 211, 212,
    214, 215, 217, 219, 220, 222, 224, 227, 228, 229, 234, 235, 236, 237,
    213, 218, 226, 238 }

local SITI = {
    { va = 0x140F2CFA0, cave = 0x000, orig = "\x48\x8B\xC4\x44\x89\x48\x20\x4C\x89\x40\x18\x89\x50\x10" },
    { va = 0x140EE5C6C, cave = 0x200, orig = "\x41\x8D\x47\xFE\x83\xF8\x15\x0F\x87\x61\x04\x00\x00" },
}
local CODICE = "4C8B15F90F00004D85D20F84DA00000089D025FF3F00003D400600000F87C80000004C8D1DD7120000410FB6040385C00F84B4000000450FB7D84181FB11CA00000F87A30000004D69DB7C0100004D01DAA801740A4180BA78010000167353A8020F8483000000450FB79A440100004181FBFF01000077724C8D158110000043803C1A007564A80474214589CA4181E2FF3F00004181FA40060000770E4C8D1D5C12000043F6041308753FB802000000EB05B801000000448B154A0F0000FF05440F00004181E2FF0000004C8D1D2E1900004F8D1CD341891366458943044188430641C643074131C0C389D025FF3F00003D400600000F87C00000004C8D1DFD200000410FB6040385C00F84AC0000004C8B15E90E00004D85D20F849C000000450FB7D84181FB11CA00000F878B0000004D69DB7C0100004D01DA83F80175204180BA790100004E73724180BA780100001577364180BA7901000048735EEB2A83F802750C4180BA7801000018764DEB1983F80375464180BA780100001B733C4180BA79010000507332450FB7D84569DBB179379E44031D642700004569DB6BCAEB8541C1EB10456BDB0541C1EB104585DB740883C010E9FBFEFFFF4889E0448948204C89401889501049BBAECFF2400100000041FFE366662E0F1F84000000000066662E0F1F84000000000066662E0F1F8400000000000F1F8400000000004183FF037507C605FF0D0000004183FF020F83160100008B44242483F80B740983F8030F85040100004153524C8B15CD0D00004D85D20F84E70000008B44245825FF3F00003D400600000F87D30000004C8D1DA9100000410FB6140385D20F84BF0000000FB74424503D11CA00000F87AF0000004869C07C0100004901C2F6C201740A4180BA78010000167350F6C2020F848D000000410FB782440100003DFF010000777E4C8D1D540E000041803C03007570F6C2047421418B822C01000025FF3F00003D40060000770E4C8D1D2E10000041F6040308754AB202EB02B20141BF030000008B051D0D0000FF05170D000025FF0000004C8D1D031700004D8D1CC38B442458418903668B44245066418943044188530641C64307428815EB0C0000EB07C605E20C0000005A415B418D47FE83F815770D49BA795CEE400100000041FFE249BADA60EE400100000041FFE2"
local C_BLOCCO, C_GIRO, C_UE, C_FLAGS, C_ANELLO = 0x1000, 0x1008, 0x1100, 0x1300, 0x1A00
local C_MOTIVO = 0x100C
local C_CARATT, C_SEME_C = 0x2200, 0x2900   -- v1.8: carattere dei club
   -- v1.5: il motivo dell'ultimo blocco, per "Frasi del mercato"
local N_SQUADRE = 1601
local SQ_TAB, SQ_PASSO, SQ_SERIE = 0x1877070, 0x690, 748

local RECORD = 0x17C
local O_INDICE, O_CODICE, O_CODICE2, O_NOME = 0x02C, 0x030, 0x034, 0x038
local O_CLUB, O_PADRONE, O_NAZ, O_ETA = 0x12C, 0x160, 0x144, 0x178
local PER_GIRO, MASSIMO_RECORD, VUOTI_FINE = 2000, 0xCA11, 100

local F_FINESTRA = "SiderAddons\\Regole di tesseramento - finestra.txt"
local F_DIARIO   = "SiderAddons\\Regole di tesseramento - diario.txt"

local eco, cave = nil, nil
local contesto = nil       -- v1.8: per leggere ctx.identita
local TIPI = { GRANDE = 1, VIVAIO = 2, ESPERIENZA = 3 }
local NOMI_TIPI = { "GRANDE", "VIVAIO", "ESPERIENZA" }
local ue = {}
local prima = nil          -- indice giocatore -> club (indice squadra), dall'ultimo giro
local padrone_prima = nil
local finestra = nil       -- { id, arrivi = {db -> n}, base = {db -> n} }
local giro = nil
local ultimo_giorno = nil
local letti = 0
local giro_car = false

local function L(s) log("[TESSERAMENTO] " .. s) end
local function D(s)
    local f = io.open(F_DIARIO, "a")
    if f then f:write(s, "\n"); f:close() end
end
local function dahex(h) return (string.gsub(h, "%x%x", function(x) return string.char(tonumber(x, 16)) end)) end
local function u64_le(n) local t = {} for i = 1, 8 do t[i] = string.char(n % 256); n = math.floor(n / 256) end return table.concat(t) end
local function u16(s, i) local a, b = string.byte(s, i, i + 1); return b * 256 + a end
local function u32(s, i) local a, b, c, d = string.byte(s, i, i + 3); return ((d * 256 + c) * 256 + b) * 256 + a end
local function numerico(p) if type(p) == "number" then return p end return tonumber(ffi.cast("uint64_t", p)) end

-- ---- i conti della finestra, su file ------------------------------------
local function id_finestra(mm, aa) return aa * 2 + ((mm >= 6) and 1 or 0) end
local function nome_finestra(id)
    local aa = math.floor(id / 2)
    return (id % 2 == 1) and ("estate " .. aa) or ("inverno " .. aa)
end
local function salva_finestra()
    local f = io.open(F_FINESTRA, "w")
    if not f then return end
    f:write("finestra;", finestra.id, "\n")
    for db, n in pairs(finestra.arrivi) do f:write("arrivi;", db, ";", n, "\n") end
    for db, n in pairs(finestra.base) do f:write("base;", db, ";", n, "\n") end
    f:close()
end
local function carica_finestra(id)
    finestra = { id = id, arrivi = {}, base = {}, nuova = true }
    local f = io.open(F_FINESTRA, "r")
    if not f then return end
    local ok = false
    for riga in f:lines() do
        local k, a, b = string.match(riga, "^(%a+);(%d+);?(%d*)")
        if k == "finestra" then ok = (tonumber(a) == id)
        elseif ok and k == "arrivi" then finestra.arrivi[tonumber(a)] = tonumber(b)
        elseif ok and k == "base" then finestra.base[tonumber(a)] = tonumber(b) end
    end
    f:close()
    if ok then finestra.nuova = false end
end

-- ---- il giro sui giocatori, a pezzi -------------------------------------
-- The Gaffer (pc196): la tabella delle squadre non e' sempre allo stesso posto (dipende dalla versione di fl26caps /
-- FL Mod Studio: 0x1877070 prima della 0.2.0, 0x193F170 con il calendario largo della 0.2.0). Al primo giro si prova
-- ogni posto noto e si tiene quello dove i record hanno davvero l'indice giusto (v % 16384 == i); se nessuno va bene,
-- il modulo non fa niente (meglio nessuna regola che regole sui club sbagliati).
local SQ_CANDIDATI = { 0x1877070, 0x193F170 }
local SQ_TROVATA = nil
local function trova_tabella(b)
    for _, base in ipairs(SQ_CANDIDATI) do
        local buoni = 0
        for i = 0, 63 do
            local h = memory.read(b + base + i * SQ_PASSO, 4)
            if h and u32(h, 1) ~= 0xFFFFFFFF and u32(h, 1) % 16384 == i then buoni = buoni + 1 end
        end
        if buoni >= 48 then
            -- 1.600 o piu' club? (FL Mod Studio 0.2.2+: 2.400 - il codice nel gioco conta fino a 1.600)
            local oltre = 0
            for i = 1601, 1640 do
                local h = memory.read(b + base + i * SQ_PASSO, 4)
                if h and u32(h, 1) ~= 0xFFFFFFFF and u32(h, 1) % 16384 == i then oltre = oltre + 1 end
            end
            if oltre > 0 then
                L(string.format("tabella squadre a 0x%X ma con piu' di 1.600 club: versione non supportata, non faccio niente", base))
                return false
            end
            SQ_TAB = base
            L(string.format("tabella squadre trovata a 0x%X (%d/64 record giusti)", base, buoni))
            return true
        end
    end
    L("tabella squadre non trovata (versione di fl26caps diversa): non faccio niente")
    return false
end

local function serie_squadre(b)
    local serie, db = {}, {}
    for i = 0, N_SQUADRE - 1 do
        local a = b + SQ_TAB + i * SQ_PASSO
        local h = memory.read(a, 4)
        local s = memory.read(a + SQ_SERIE, 1)
        if h and s then
            local v = u32(h, 1)
            if v ~= 0xFFFFFFFF and v % 16384 == i then
                serie[i] = string.byte(s); db[i] = math.floor(v / 16384)
            end
        end
    end
    return serie, db
end

local function lavora_un_pezzo()
    local b = giro.blocco
    local quanti = PER_GIRO
    if giro.i + quanti > MASSIMO_RECORD then quanti = MASSIMO_RECORD - giro.i end
    local d = memory.read(b + giro.i * RECORD, quanti * RECORD)
    if not d then giro.fine = true; return end
    for k = 0, quanti - 1 do
        local o = k * RECORD
        local pos = giro.i + k
        local cod = u32(d, o + O_CODICE + 1)
        if cod == 0 or cod ~= u32(d, o + O_CODICE2 + 1) or u32(d, o + O_INDICE + 1) % 65536 ~= pos % 65536 then
            giro.vuoti = giro.vuoti + 1
            if giro.vuoti >= VUOTI_FINE then giro.fine = true; break end
        else
            giro.vuoti = 0
            local club = u32(d, o + O_CLUB + 1) % 16384
            local padrone = u32(d, o + O_PADRONE + 1) % 16384
            local naz = u16(d, o + O_NAZ + 1)
            local extra = not ue[naz]
            if club < N_SQUADRE then
                if string.byte(d, o + O_ETA + 1) > ETA_LIBERA then giro.over[club] = (giro.over[club] or 0) + 1 end
                if extra then giro.extra[club] = (giro.extra[club] or 0) + 1 end
            end
            -- arrivi di extracomunitari dall'estero (solo per le regole "nuovi")
            if prima and extra and club < N_SQUADRE then
                local era = prima[pos]
                if era and era ~= club and padrone_prima[pos] ~= club then
                    local r = REGOLE[giro.serie[club] or -1]
                    if r and r.nuovi_extra and not ITALIA[giro.serie[era] or -1] then
                        giro.nuovi[club] = (giro.nuovi[club] or 0) + 1
                    end
                end
            end
            giro.club[pos] = club
            giro.padrone[pos] = padrone
        end
    end
    giro.i = giro.i + quanti
    if giro.i >= MASSIMO_RECORD then giro.fine = true end
end

local function finisci()
    local serie, db = giro.serie, giro.db
    -- nuovi arrivi nei conti della finestra
    local cambiato = false
    for i, n in pairs(giro.nuovi) do
        local k = db[i]
        if k then finestra.arrivi[k] = (finestra.arrivi[k] or 0) + n; cambiato = true end
    end
    -- base degli extracomunitari a inizio finestra (Spagna, Francia)
    for i, s in pairs(serie) do
        local r = REGOLE[s]
        if r and r.extra_in_rosa and finestra.base[db[i]] == nil then
            finestra.base[db[i]] = giro.extra[i] or 0; cambiato = true
        end
    end
    if cambiato then salva_finestra() end
    -- le bandierine per il codice nel gioco
    local t = {}
    local n_lista, n_extra = 0, 0
    for i = 0, N_SQUADRE - 1 do
        local f = 0
        local s = serie[i]
        if s and ITALIA[s] then f = f + 8 end
        local r = s and REGOLE[s]
        if r then
            if r.lista and (giro.over[i] or 0) >= r.lista then f = f + 1; n_lista = n_lista + 1 end
            if r.nuovi_extra and (finestra.arrivi[db[i]] or 0) >= r.nuovi_extra then f = f + 2 + 4; n_extra = n_extra + 1 end
            if r.extra_in_rosa then
                local tetto = math.max(r.extra_in_rosa, finestra.base[db[i]] or 0)
                if (giro.extra[i] or 0) >= tetto then
                    if f % 4 < 2 then f = f + 2 end
                    n_extra = n_extra + 1
                end
            end
        end
        t[#t + 1] = string.char(f)
    end
    memory.write(cave + C_FLAGS, table.concat(t))
    -- v1.8: il carattere di chi compra
    local id = contesto and contesto.identita and contesto.identita.tipo and contesto.identita.tipo()
    local n_car = 0
    if id then
        local c = {}
        for i = 0, N_SQUADRE - 1 do
            local v = (db[i] and TIPI[id[db[i]] or ""]) or 0
            if v > 0 then n_car = n_car + 1 end
            c[#c + 1] = string.char(v)
        end
        memory.write(cave + C_CARATT, table.concat(c))
    end
    memory.write(cave + C_SEME_C, string.char(finestra.id % 256, math.floor(finestra.id / 256) % 256, 0x5A, 0x3C))
    memory.write(cave + C_BLOCCO, u64_le(numerico(giro.blocco)))   -- v1.3: il blocco e' un puntatore nativo
    prima, padrone_prima = giro.club, giro.padrone
    if giro.primo or (n_car > 0 and not giro_car) then
        L(string.format("%s: %s; %d club con la lista piena, %d senza posti da extracomunitario; %d club con il carattere negli acquisti",
            giro.quando, nome_finestra(finestra.id), n_lista, n_extra, n_car))
        if n_car > 0 then giro_car = true end
    end
end

-- gli acquisti bloccati, dal codice nel gioco al diario
local scritti, scritti_giorno = {}, nil   -- v1.9: niente doppioni nel diario
local function leggi_bloccati()
    local s = memory.read(cave + C_GIRO, 4)
    if not s then return end
    local n = u32(s, 1)
    if n - letti > 256 then letti = n - 256 end
    if letti >= n then return end
    local b = eco.blocco()
    local g, mm, aa = eco.data()
    local quando = (g and mm and aa) and string.format("%02d/%02d/%d", g, mm, aa) or "?"
    while letti < n do
        local e = memory.read(cave + C_ANELLO + (letti % 256) * 8, 8)
        local sq, idx, perche, chi = u32(e, 1), u16(e, 5), string.byte(e, 7), string.byte(e, 8)
        local nome = "?"
        if b and idx < MASSIMO_RECORD then
            local r = memory.read(b + idx * RECORD + O_NOME, 40)
            nome = r and (string.match(r, "^([^%z]*)") or "?") or "?"
        end
        local riga = string.format("%s  %s  squadra %d  %s  bloccato: %s", quando, chi == 0x42 and "TU " or "CPU",
            math.floor(sq / 16384), nome, perche == 1 and "lista dei 25 piena"
            or perche == 2 and "niente posto da extracomunitario"
            or ("fuori dal carattere del club (" .. (NOMI_TIPI[perche - 16] or "?") .. ")"))
        if scritti_giorno ~= quando then scritti, scritti_giorno = {}, quando end
        if not scritti[riga] then scritti[riga] = true; D(riga) end
        letti = letti + 1
    end
end

local function gira()
    if not cave or not eco or not eco.pronta() then return end
    leggi_bloccati()
    local g, mm, aa = eco.data()
    if not (g and mm and aa) then return end
    if not giro then
        local oggi = aa * 10000 + mm * 100 + g
        if oggi == ultimo_giorno then return end
        local b = eco.blocco()
        if not b then return end
        if SQ_TROVATA == nil then SQ_TROVATA = trova_tabella(b) end
        if not SQ_TROVATA then return end
        local id = id_finestra(mm, aa)
        if not finestra or finestra.id ~= id then
            local cambio = finestra ~= nil
            carica_finestra(id)
            if cambio then finestra.arrivi, finestra.base = {}, {} end
        end
        local serie, db = serie_squadre(b)
        giro = { blocco = b, i = 0, vuoti = 0, over = {}, extra = {}, nuovi = {}, club = {}, padrone = {},
                 serie = serie, db = db, oggi = oggi, primo = (ultimo_giorno == nil),
                 quando = string.format("%02d/%02d/%d", g, mm, aa) }
    end
    -- v1.1: tutto il giro in una volta (a pezzi da 2000 giocatori): nei menu
    -- gli eventi sono pochi e a un pezzo per evento le regole partivano tardi
    while not giro.fine do lavora_un_pezzo() end
    if giro.fine then
        ultimo_giorno = giro.oggi
        finisci()
        giro = nil
        if collectgarbage then collectgarbage() end
    end
end

function m.set_teams(ctx) gira() end
function m.after_set_conditions(ctx) gira() end
function m.get_stadium_name(ctx, a, b, c) gira(); return nil end

function m.init(ctx)
    L("v" .. m.version)
    eco = ctx.economia
    contesto = ctx
    if not eco then L("manca Economia Lunga - motore (deve stare PRIMA in sider.ini)"); return end
    if ffi == nil then L("luajit.ext non disponibile: non faccio niente"); return end
    for _, x in ipairs(SITI) do
        if memory.read(x.va, #x.orig) ~= x.orig then
            L(string.format("a 0x%X i byte non sono gli originali: non tocco niente", x.va)); return
        end
    end
    for _, n in ipairs(COMUNITARI) do ue[n] = true end
    ffi.cdef[[
    void* Tesseramento_VirtualAlloc(void* a, uint64_t n, uint32_t t, uint32_t p) __asm__("VirtualAlloc");
    ]]
    local p = ffi.C.Tesseramento_VirtualAlloc(nil, 0x3000, 0x3000, 0x40)
    if p == nil then L("memoria non concessa: non faccio niente"); return end
    cave = numerico(p)
    local codice = dahex(CODICE)
    memory.write(cave, codice)
    if memory.read(cave, #codice) ~= codice then L("codecave rifiutato"); cave = nil; return end
    local t = {}
    for i = 0, 511 do t[i + 1] = ue[i] and "\1" or "\0" end
    memory.write(cave + C_UE, table.concat(t))
    memory.write(cave + C_FLAGS, string.rep("\0", N_SQUADRE))
    memory.write(cave + C_BLOCCO, string.rep("\0", 8))
    for i, x in ipairs(SITI) do
        local salto = "\x49\xBB" .. u64_le(cave + x.cave) .. "\x41\xFF\xE3"
        salto = salto .. string.rep("\x90", #x.orig - #salto)
        memory.write(x.va, salto)
        if memory.read(x.va, #salto) ~= salto then
            for k = 1, i do memory.write(SITI[k].va, SITI[k].orig) end
            L("aggancio non riuscito: rimessi gli originali"); cave = nil; return
        end
    end
    L("ATTIVA: regole di tesseramento per te e per la CPU")
    -- v1.5: "Frasi del mercato" legge qui il motivo del blocco e lo scrive al posto di "rosa troppo grande"
    ctx.tesseramento = { motivo = cave + C_MOTIVO }
    if eco.registra_giro then eco.registra_giro(gira)
    else
        ctx.register("set_teams", m.set_teams)
        ctx.register("after_set_conditions", m.after_set_conditions)
        ctx.register("get_stadium_name", m.get_stadium_name)
    end
end

return m
