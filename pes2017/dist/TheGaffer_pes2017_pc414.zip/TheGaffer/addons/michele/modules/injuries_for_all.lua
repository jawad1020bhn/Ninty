-- injuries_for_all.lua  -  REAL INJURIES FOR ALL (CPU included)  v1.1-gaffer3  -  for FOOTBALL LIFE 2026 (FL26)
-- gaffer1 (The Gaffer app, with Michele's permission): settings from injuries_for_all.ini (written by the app's Setup:
--   level = light | realistic | heavy), and the list of injured players is written to
--   content\ml-immersion\bridge\injuries.csv (player id, days) so the app knows every injury without the F7 dump.
-- gaffer2 (crash fix): v1.0 looked for short names ("J. Stones") in all memory; in many databases they are not in the
--   live table, so it never found it and repeated a full memory scan at every menu/match start. Now only the big
--   memory blocks (8 MB+) are checked at their start, where the live table sits (as PlayerDump finds it). The search never runs while a match is being
--   prepared (set_teams / stadium), at most every 60 s, and stops after 5 failures in a session.
--   Everything else is Michele's v1.1 logic, unchanged.
-- by Michele, written together with Claude (Anthropic) - 28/10/2026, v1.1 29/10/2026
-- v1.1 (Michele): safe memory access (ReadProcessMemory/WriteProcessMemory: memory freed by the game gives an error,
--       never a crash) and the player table is used only after it is found twice in the same place, 30+ s apart.
-- MASTER LEAGUE ONLY. Requires Sider with  luajit.ext.enabled = 1
--
-- What it does
--  1) The game gives CPU players (and often yours) only 1-5 day injuries, so they are always healed
--     for the next match. When such a short injury appears, this module draws a realistic length:
--     many short ones, a lot of 1-3 weeks, some of months, rare ones of 4-8 months.
--     Injuries already longer than 5 days are left alone.
--  2) New injuries: every calendar day that passes, a small share of the healthy players in the
--     whole world (PROB_GIORNO) gets injured, with the same lengths. Works with played AND simulated
--     matches. In our test the world settled at about 6% injured players (like a real league).
--  3) Same rules for everybody: your club and the CPU. A CPU striker out for 4 months forces the
--     CPU to use the bench or the transfer market.
--  Safety: new injuries are only created in the calendar, never while the line-ups of a match are
--  already decided (otherwise the CPU could field an injured player and the game could crash).
--
-- Where the data is: Master League player table, 380 bytes per player, player ID written twice
-- just before the name, injury days left = 1 byte, 272 bytes after the name. The game counts the
-- days down by itself and the CPU leaves injured players out of its line-up.
--
-- Settings: the values just below (PROB_GIORNO = injuries per day, FASCE = length table).
-- Everything the module does is written in sider.log (lines "INJURIES FOR ALL").
local m = {}
-- gaffer2: Sider's Lua has no global pcall; same fallback as GrowthBridge
local pcall = pcall
if not pcall then
    if xpcall then
        pcall = function(f, ...)
            local a = { ... }
            return xpcall(function() return f((unpack or table.unpack)(a)) end, function(e) return e end)
        end
    else
        pcall = function(f, ...) return true, f(...) end
    end
end

local PASSO, OFF_GIORNI = 380, 272
local SOGLIA_BREVE = 5          -- injuries of 1-5 days = the "fake" ones the game gives, to be made realistic
local PROB_GIORNO = 0.0025      -- share of healthy players injured per calendar day (about 1% every 4 days)
-- { min days, max days, weight }  (out of 100 injuries)
local FASCE = {
    { 0,   0,   42 },   -- stays short (1-5 days)
    { 7,   21,  33 },   -- 1-3 weeks
    { 22,  60,  16 },   -- 3 weeks - 2 months
    { 61,  120, 6 },    -- 2-4 months
    { 121, 180, 2 },    -- 4-6 months
    { 181, 248, 1 },    -- 6-8 months (the game cannot go over 255 days)
}
-- names used to find the player table in memory
local ANCORE = { "Virgil van Dijk", "Mohamed Salah", "Erling Haaland", "Lionel Messi", "Bernardo Silva", "John Stones",
                 "J. Stones", "M. Verratti", "T. Alexander-Arnold", "X. Simons", "M. Lorber" }
local ricerche_fallite = 0
local in_attesa = false       -- gaffer3: tables found, nobody injured yet
local candidata = nil         -- v1.1: table seen once, waiting for confirmation
local FILE = "injuries_for_all.txt"   -- IDs of injuries already decided and not yet healed (kept between sessions)
local INI = "injuries_for_all.ini"    -- gaffer1: level = light | realistic | heavy
local OUT = "content\\ml-immersion\\bridge\\injuries.csv"   -- gaffer1: injured players for the app
local LIVELLO = "realistic"
local LIVELLI = {
    light     = { 0.0012, { 55, 30, 10, 4, 1, 0 } },
    realistic = { 0.0025, { 42, 33, 16, 6, 2, 1 } },
    heavy     = { 0.0040, { 35, 33, 19, 9, 3, 1 } },
}
local ultimo_out = -100

local mbi, tabella, decisi, ultimo, ultima_ricerca = nil, nil, {}, 0, -100
local allungati, lasciati, nuovi = 0, 0, 0
local campione, ultimo_giro, ultimo_campione = {}, 0, -100   -- reference injured players, to notice the days passing
local nel_mondo, pre_partita, debito = 0, false, 0   -- pre_partita: line-ups already made, no new injuries now
local t_partita, avviato = 0, false   -- gaffer2: time of set_teams; start wave done
-- gaffer2: a match is being prepared/played (set_teams seen less than 45 minutes ago and no match end yet)
local function in_partita() return pre_partita and os.time() - t_partita < 2700 end

if ffi ~= nil then
    ffi.cdef[[
    typedef struct { uint64_t Base; uint64_t AllocBase; uint32_t AllocProtect; uint32_t pad1;
                     uint64_t Size; uint32_t State; uint32_t Protect; uint32_t Type; uint32_t pad2; } IFA_MBI;
    size_t IFA_VirtualQuery(const void* a, IFA_MBI* b, size_t l) __asm__("VirtualQuery");
    void* IFA_GetCurrentProcess(void) __asm__("GetCurrentProcess");
    int IFA_ReadProcessMemory(void* h, const void* a, void* b, size_t n, size_t* r) __asm__("ReadProcessMemory");
    int IFA_WriteProcessMemory(void* h, void* a, const void* b, size_t n, size_t* r) __asm__("WriteProcessMemory");
    ]]
end

local function L(s) log("INJURIES FOR ALL: " .. s) end
-- v1.1: safe memory access
local proc, piccolo, letti, grande, grande_n = nil, nil, nil, nil, 0
local function u32(a)
    if ffi.C.IFA_ReadProcessMemory(proc, ffi.cast("const void*", a), piccolo, 4, letti) == 0 then return nil end
    return tonumber(ffi.cast("const uint32_t*", piccolo)[0])
end
local function u16(a)
    if ffi.C.IFA_ReadProcessMemory(proc, ffi.cast("const void*", a), piccolo, 2, letti) == 0 then return nil end
    return tonumber(ffi.cast("const uint16_t*", piccolo)[0])
end
local function u8(a)
    if ffi.C.IFA_ReadProcessMemory(proc, ffi.cast("const void*", a), piccolo, 1, letti) == 0 then return nil end
    return tonumber(piccolo[0])
end
local function scrivi8(a, v)
    piccolo[0] = v
    return ffi.C.IFA_WriteProcessMemory(proc, ffi.cast("void*", a), piccolo, 1, letti) ~= 0
end
local function leggi(a, n)
    if n > grande_n then grande = ffi.new("uint8_t[?]", n); grande_n = n end
    if ffi.C.IFA_ReadProcessMemory(proc, ffi.cast("const void*", a), grande, n, letti) == 0 then return nil end
    return ffi.string(grande, tonumber(letti[0]))
end

local function regione(a)
    if ffi.C.IFA_VirtualQuery(ffi.cast("const void*", a), mbi, 48) == 0 then return nil end
    if mbi.State ~= 0x1000 or mbi.Protect ~= 0x04 then return nil end
    return tonumber(mbi.Base), tonumber(mbi.Base) + tonumber(mbi.Size)
end

local function valido(p, lo, hi)
    if p - 8 < lo or p + PASSO > hi then return false end
    local a, b = u32(p - 8), u32(p - 4)
    if not a or a ~= b or a == 0 or a > 20000000 then return false end
    local c = u8(p)
    return c ~= nil and c >= 0x20 and c < 0xF8
end

local function nome(p)
    local s = leggi(p, 60)
    return s and s:match("^[^%z]*") or "?"
end

local function carica_ini(ctx)
    local f = io.open(ctx.sider_dir .. INI, "r")
    if f then
        for riga in f:lines() do
            local v = riga:match("^%s*level%s*=%s*(%a+)")
            if v and LIVELLI[v:lower()] then LIVELLO = v:lower() end
        end
        f:close()
    end
    local lv = LIVELLI[LIVELLO]
    PROB_GIORNO = lv[1]
    for i, w in ipairs(lv[2]) do FASCE[i][3] = w end
end

-- gaffer1: injured players (id,days) for the app; at most every 20 s unless forced
local function scrivi_out(ctx, massimo, forza)
    if not forza and os.clock() - ultimo_out < 20 then return end
    ultimo_out = os.clock()
    -- (Sider's Lua has no os.remove/os.rename: the file is written in one go; the app ignores a half-written last line)
    local righe = { "# INJURIES FOR ALL " .. LIVELLO .. " " .. os.time() }
    for id, g in pairs(massimo) do righe[#righe + 1] = id .. "," .. g end
    local f = io.open(ctx.sider_dir .. OUT, "w")
    if not f then return end
    f:write(table.concat(righe, "\n") .. "\n# end\n")
    f:close()
end

local function carica_decisi(ctx)
    local f = io.open(ctx.sider_dir .. FILE, "r")
    if not f then return end
    for riga in f:lines() do local id = tonumber(riga); if id then decisi[id] = true end end
    f:close()
end

local function riscrivi(ctx)
    local f = io.open(ctx.sider_dir .. FILE, "w")
    if not f then return end
    for id in pairs(decisi) do f:write(id .. "\n") end
    f:close()
end

-- finds the live table: more than 10000 players and at least one injured
local function trova_tabella(ctx)
    -- gaffer2: the live player table is one big block of its own (25,000+ players x 380 B, about 10 MB) and starts a few
    -- bytes after the start of that block (PlayerDump: always block + 0x10). So: list the read/write blocks of 8 MB or
    -- more and test only their first bytes. No text search through memory (the names are not where v1.0 expected them).
    local addr, zone = 65536, {}
    while addr < 140737488289792 do
        if ffi.C.IFA_VirtualQuery(ffi.cast("const void*", addr), mbi, 48) == 0 then break end
        local base, size = tonumber(mbi.Base), tonumber(mbi.Size)
        if size <= 0 then break end
        if mbi.State == 0x1000 and mbi.Protect == 0x04 and size >= 0x800000 then zone[#zone + 1] = { base, size } end
        addr = base + size
    end
    local best, bn, binf, cands = nil, 0, -1, 0
    -- gaffer3: PlayerDump 1.6 shares its hook pointer (last player record the game touched = the career table)
    local tocco = nil
    if ctx and ctx.gaffer_player_ptr then
        local lo32, hi32 = u32(ctx.gaffer_player_ptr), u32(ctx.gaffer_player_ptr + 4)
        if lo32 and hi32 then tocco = hi32 * 4294967296 + lo32 end
        if tocco == 0 then tocco = nil end
    end
    for _, z in ipairs(zone) do
        local lo, hi = z[1], z[1] + z[2]
        for off = 0, 0x100, 8 do
            local p = lo + off + 0x38          -- name of the first player (id twice just before it)
            if valido(p, lo, hi) and valido(p + PASSO, lo, hi) and valido(p + 2 * PASSO, lo, hi) then
                -- the Master League table has a loan-expiry field (record +0x16C = name +0x134): FF FF 00 00 when not on
                -- loan, or a date. The database copy does not, so it is told apart even when nobody is injured.
                local n, inf, ml, pres, r = 0, 0, 0, 0, p
                while valido(r, lo, hi) do
                    n = n + 1
                    if (u8(r + OFF_GIORNI) or 0) > 0 then inf = inf + 1 end
                    local y = u16(r + 0x134) or 0
                    if y == 0xFFFF or (y >= 1990 and y <= 2100) then ml = ml + 1 end
                    if y >= 1990 and y <= 2100 then pres = pres + 1 end   -- players really on loan: only in the career
                    r = r + PASSO
                end
                if n > 10000 then
                    cands = cands + 1
                    local dentro = tocco and tocco >= p - 0x38 and tocco < p - 0x38 + n * PASSO
                    L(string.format("  candidate table at 0x%X: %d players, %d injured, %d on loan%s", p, n, inf, pres, dentro and ", the game uses it (PlayerDump)" or ""))
                    -- 1) the table the game is using (PlayerDump pointer); 2) Michele's rule: the one with the game's injuries
                    local sc = (ml > n * 0.8 and dentro) and 2000000000 or (ml > n * 0.8 and inf > 0) and (1000000000 + inf) or -1
                    if sc > binf then best, bn, binf = p, n, sc end
                end
                break
            end
        end
    end
    if best and binf >= 1000000000 then return best, bn end
    if cands > 0 then
        L("nobody is injured in the world yet and " .. (tocco and "the PlayerDump pointer is in none of the tables" or "no PlayerDump pointer yet")
          .. ": open the info page of any player (Team Management) or wait for the first injury")
        return nil, nil, true
    end
    L(string.format("searched %d big memory blocks, no player table", #zone))
    return nil
end

local function tira_durata()
    local tot = 0
    for _, f in ipairs(FASCE) do tot = tot + f[3] end
    local x, acc = math.random(tot), 0
    for _, f in ipairs(FASCE) do
        acc = acc + f[3]
        if x <= acc then
            if f[2] == 0 then return nil end
            return math.random(f[1], f[2])
        end
    end
    return nil
end

local function durata_nuovo()
    local d = tira_durata()
    if not d then d = math.random(1, SOGLIA_BREVE) end
    return d
end

-- new injuries for the days that passed
local function nuovi_infortuni(ctx, giorni)
    if not tabella then return end
    local lo, hi = regione(tabella)
    if not lo then return end
    local schede, sani = {}, {}
    local p = tabella
    while valido(p, lo, hi) do
        local id = u32(p - 8) or 0
        local l = schede[id]
        if not l then l = {}; schede[id] = l; sani[#sani + 1] = id end
        l[#l + 1] = p
        p = p + PASSO
    end
    local prob = 1 - (1 - PROB_GIORNO) ^ giorni
    local conta, brevi, sett, mesi, feriti = 0, 0, 0, 0, 0
    for _, id in ipairs(sani) do
        local ferito = false
        for _, q in ipairs(schede[id]) do if (u8(q + OFF_GIORNI) or 0) > 0 then ferito = true; break end end
        if ferito then feriti = feriti + 1 end
        if not ferito and math.random() < prob then
            local d = durata_nuovo()
            for _, q in ipairs(schede[id]) do scrivi8(q + OFF_GIORNI, d) end
            decisi[id] = true
            conta = conta + 1
            if d <= 6 then brevi = brevi + 1 elseif d <= 30 then sett = sett + 1 else mesi = mesi + 1 end
            if d > 60 then L(string.format("  long injury: %s (id %d) %d days", nome(schede[id][1]), id, d)) end
        end
    end
    nuovi = nuovi + conta
    riscrivi(ctx)
    nel_mondo = feriti + conta
    L(string.format("%d days passed: %d new injuries (up to 6 days %d, 1-4 weeks %d, over a month %d)", giorni, conta, brevi, sett, mesi))
    L(string.format("injured players in the world now: %d of %d (%.1f%%)", nel_mondo, #sani, 100 * nel_mondo / math.max(1, #sani)))
end

local MAX_RICERCHE = 10
local function controlla(ctx, nuovo_campione, puo_cercare)
    if os.clock() - ultimo < 2 then return end
    ultimo = os.clock()
    if tabella then
        local lo, hi = regione(tabella)
        if not lo or not valido(tabella, lo, hi) then tabella = nil end
    end
    if not tabella then
        -- gaffer2: search only when allowed (never while a match is prepared), every 60 s, at most 5 failures per session
        -- puo_cercare: true = from file loads (not while a match is prepared), "overlay" = you opened this page
        if not puo_cercare or (in_partita() and puo_cercare ~= "overlay") or ricerche_fallite >= MAX_RICERCHE then return end
        if os.clock() - ultima_ricerca < 60 then return end
        ultima_ricerca = os.clock()
        local q, n, aspetta = trova_tabella(ctx)
        in_attesa = aspetta and true or false
        if not q and aspetta then candidata = nil; return end   -- tables are there, no injury yet: not a failure
        if not q then
            ricerche_fallite = ricerche_fallite + 1
            L(string.format("player table not found (try %d of %d)%s", ricerche_fallite, MAX_RICERCHE, ricerche_fallite >= MAX_RICERCHE and ": module idle for this session" or ""))
            return
        end
        if candidata ~= q then
            -- v1.1: maybe a temporary copy (new career being created): use it only if it is still there next time
            candidata = q
            ultima_ricerca = os.clock() - 30   -- next search in 30 s
            L(string.format("player table seen (%d players) at 0x%X: used only if it is still there at the next check", n, q))
            return
        end
        tabella = q
        L(string.format("player table found (%d players) at 0x%X", n, q))
    end
    local lo, hi = regione(tabella)
    if not lo then tabella = nil; return end
    -- 1) collect all records: the same player can appear in more than one record
    local schede, massimo = {}, {}
    local p, cambiati = tabella, false
    while valido(p, lo, hi) do
        local g = (u8(p + OFF_GIORNI) or 0)
        if g > 0 then
            local id = u32(p - 8) or 0
            local l = schede[id]
            if not l then l = {}; schede[id] = l end
            l[#l + 1] = p
            if g > (massimo[id] or 0) then massimo[id] = g end
        end
        p = p + PASSO
    end
    -- 2) fully healed: next injury gets a new draw
    for id in pairs(decisi) do
        if not massimo[id] then decisi[id] = nil; cambiati = true end
    end
    -- 3) new injuries: one decision per player, written in all his records
    for id, g in pairs(massimo) do
        if not decisi[id] then
            decisi[id] = true
            cambiati = true
            if g <= SOGLIA_BREVE then
                local nuovo = tira_durata()
                if nuovo and nuovo > g then
                    for _, q in ipairs(schede[id]) do scrivi8(q + OFF_GIORNI, nuovo) end
                    allungati = allungati + 1
                    L(string.format("%s (id %d): %d -> %d days (%d records)", nome(schede[id][1]), id, g, nuovo, #schede[id]))
                else
                    lasciati = lasciati + 1
                end
            end
        end
    end
    if cambiati then riscrivi(ctx) end
    for id, l in pairs(schede) do massimo[id] = (u8(l[1] + OFF_GIORNI) or 0) end   -- after lengthening
    scrivi_out(ctx, massimo, cambiati)
    if not nuovo_campione and #campione >= 5 then return end
    -- sample: up to 60 injured players with 10+ days, to notice the days passing
    campione = {}
    for id, l in pairs(schede) do
        if #campione >= 60 then break end
        local g = (u8(l[1] + OFF_GIORNI) or 0)
        if g >= 10 then campione[#campione + 1] = { l[1], g } end
    end
    ultimo_campione = os.clock()
    -- gaffer2: days are noticed only through injured players (10+ days). If the world has almost none (it happens:
    -- the game heals everybody in 1-5 days), the module would never see a day pass. So, once per session, outside a
    -- match, it creates the injuries of 10 calendar days at once, with the same rules.
    -- (from this page in a menu, or when no match was set up in the last 45 minutes; the game calls set_teams also
    --  when a career is loaded and at every match start, so after a match the page is the safe moment)
    if #campione < 5 and not avviato and (puo_cercare == "overlay" or not in_partita()) then
        avviato = true
        L("almost nobody is injured with 10+ days: start wave (as if 10 days had passed)")
        nuovi_infortuni(ctx, 10)
        campione = {}
        local lo2, hi2 = regione(tabella)
        local q = tabella
        while lo2 and valido(q, lo2, hi2) and #campione < 60 do
            local g = (u8(q + OFF_GIORNI) or 0)
            if g >= 10 then campione[#campione + 1] = { q, g } end
            q = q + PASSO
        end
    end
end

-- how many days passed since the last check? nil = unclear (e.g. a save was reloaded)
local function giorni_passati()
    if not tabella or #campione < 5 then return nil end
    local lo, hi = regione(tabella)
    if not lo or not valido(tabella, lo, hi) then tabella = nil; return nil end
    local voti, validi = {}, 0
    for _, c in ipairs(campione) do
        if not valido(c[1], lo, hi) then return nil end
        local g = (u8(c[1] + OFF_GIORNI) or 0)
        if g > 0 then
            local d = c[2] - g
            voti[d] = (voti[d] or 0) + 1
            validi = validi + 1
        end
    end
    if validi < 5 then return nil end
    for d, n in pairs(voti) do
        if n >= validi * 0.7 then
            if d >= 0 and d <= 30 then return d end
            return nil
        end
    end
    return nil
end

function m.on_file(ctx, filename)
    if type(filename) == "string" and filename:find("MatchEnd.json", 1, true) then pre_partita = false end
    if os.clock() - ultimo_giro < 1 then return nil end   -- at most once per second, only a few bytes read
    ultimo_giro = os.clock()
    if not tabella then
        -- gaffer2: the only place that may search for the table (menus / file loads, never while a match is prepared)
        ultimo = 0
        controlla(ctx, true, true)
        if not tabella then return nil end
    end
    local d = giorni_passati()
    if d == nil then
        -- new sample only if the table is already known (never a long search from here), at most every 30 s
        if tabella and os.clock() - ultimo_campione > 30 then ultimo = 0; controlla(ctx, true) end
    elseif d > 0 then
        ultimo = 0
        controlla(ctx)          -- lengthen the short injuries born in these days
        if pre_partita then
            -- line-ups already prepared: these days are made up at the next check
            debito = debito + d
            pre_partita = false
        else
            nuovi_infortuni(ctx, d + debito)
            debito = 0
        end
        ultimo = 0
        controlla(ctx, true)    -- new sample
    end
    return nil
end

-- gaffer3: in some setups another module answers livecpk_rewrite first, so this module never sees file loads.
-- Keys and gamepad input arrive in every menu: they drive the same day check (at most once per second, few bytes read).
function m.on_input(ctx)
    m.on_file(ctx, nil)
    return nil
end

function m.on_menu(ctx)
    controlla(ctx)
    return nil
end

function m.on_teams(ctx)
    pre_partita = true
    t_partita = os.time()
    controlla(ctx)
    return nil
end

function m.overlay_on(ctx)
    if not tabella then
        -- gaffer2: you opened this page in a menu: search here (at most every 60 s)
        ultimo = 0
        controlla(ctx, true, "overlay")
    end
    if not tabella then
        return "INJURIES FOR ALL v1.1-gaffer3 (" .. LIVELLO .. "): " .. (in_attesa and "waiting: open the info page of any player once (Team Management > player), or wait for the first injury" or ricerche_fallite >= MAX_RICERCHE and "player table not found, idle this session (see sider.log)" or ("looking for the player table, failed tries " .. ricerche_fallite .. " of " .. MAX_RICERCHE .. " (keep this page open in a career menu)"))
    end
    return string.format("INJURIES FOR ALL v1.1-gaffer3 (" .. LIVELLO .. "): lengthened %d, left short %d, new %d (this session) - injured in the world %d", allungati, lasciati, nuovi, nel_mondo)
end

function m.init(ctx)
    if ffi == nil then L("needs luajit.ext.enabled = 1 in sider.ini - module off"); return end
    mbi = ffi.new("IFA_MBI")
    proc = ffi.C.IFA_GetCurrentProcess()
    piccolo = ffi.new("uint8_t[8]")
    letti = ffi.new("size_t[1]")
    math.randomseed(os.time())
    carica_ini(ctx)
    carica_decisi(ctx)
    ctx.register("get_stadium_name", m.on_menu)
    ctx.register("set_teams", m.on_teams)
    ctx.register("livecpk_rewrite", m.on_file)
    ctx.register("key_down", m.on_input)
    ctx.register("gamepad_input", m.on_input)
    ctx.register("overlay_on", m.overlay_on)
    L("v1.1-gaffer3 active (Master League, level " .. LIVELLO .. "): realistic injury lengths + new injuries every calendar day, CPU included")
end

return m
