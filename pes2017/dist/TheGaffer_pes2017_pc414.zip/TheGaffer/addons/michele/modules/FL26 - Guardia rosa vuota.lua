-- FL26 - Guardia rosa vuota.lua   --   v2.0   (Michele e Claude, 12 ottobre 2026)
-- Mod per Football Life 2026 (Sider). Licenza libera, con citazione.
--
-- IL PROBLEMA
-- In Master League, a volte all'inizio della stagione (1 luglio) o al
-- caricamento di una carriera, il gioco si chiude: Windows segnala
-- FL_2026.exe, eccezione 0xc0000094 (DIVISIONE PER ZERO).
-- Konami controlla le rose delle squadre (minimo 18 e massimo 35 giocatori,
-- percentuali per ruolo e nazionalita') dividendo per il numero di
-- giocatori. Nel calendario della stagione il gioco tiene pero' anche un
-- posto "vuoto" (la squadra nulla, codice 0xFFFFC289) e quando controlla
-- quello divide per zero.
--
-- COSA FA
-- Nei quattro controlli che dividono (0x140FB3A80, 0x140FB3D40, 0x140FB3F40,
-- 0x140FB4440) aggiunge il caso "zero giocatori" all'uscita che Konami usa
-- gia' per "piu' di 35": per una squadra vuota il controllo non si fa.
-- Le squadre vere non cambiano in niente.
-- Prima di scrivere controlla che i byte siano quelli originali: con
-- un'altra versione del gioco non tocca niente.
-- Non tocca l'eseguibile su disco, ne' il salvataggio, ne' il database.
--
-- In sider.ini va PRIMA delle altre mod.

local m = { version = "2.0" }
-- v2.0 (12/10/2026): versione pulita. Tolti la diagnosi, i file di prova
-- e il diario: scrive solo nel log di Sider. Le funzioni degli eventi stanno
-- nella tabella del modulo (Sider non tiene vive quelle scritte al volo).

local SITI = {
    { va = 0x140FB3AD4, cave = 0x000, originali = "\x48\x89\x45\xD0\x83\xF8\x23\x0F\x87\x42\x02\x00\x00" },
    { va = 0x140FB3D8F, cave = 0x080, originali = "\x48\xC1\xFD\x05\x83\xFD\x23\x0F\x87\xC7\x00\x00\x00" },
    { va = 0x140FB3FDE, cave = 0x0C0, originali = "\x48\xC1\xFB\x05\x48\x89\x5D\xF7\xE8\x05\x98\xFA\xFF" },
    { va = 0x140FB4510, cave = 0x140, originali = "\x48\xC1\xF8\x05\x48\x89\x44\x24\x30\xE8\xD2\x92\xFA\xFF" },
}
local CODICE_ESA = "488945D085C0741283F823773249BBE13AFB400100000041FFE3FF05A00100004C892DA1010000448B1E44891D9F010000488935A00100004C8925A101000049BB233DFB400100000041FFE366662E0F1F84000000000066662E0F1F84000000000066662E0F1F84000000000066662E0F1F8400000000000F1F84000000000048C1FD0585ED741283FD23771A49BB9C3DFB400100000041FFE3FF05200100004C89352101000049BB633EFB400100000041FFE366662E0F1F8400000000009048C1FB0548895DF785DB741A49BBF0D7F5400100000041FFD349BBEB3FFB400100000041FFE3FF05D40000004C8B5DCF4C891DD100000049BB1644FB400100000041FFE366662E0F1F84000000000066662E0F1F84000000000066662E0F1F84000000000066662E0F1F84000000000066662E0F1F8400000000000F1F44000048C1F805488944243085C0741A49BBF0D7F5400100000041FFD349BB1E45FB400100000041FFE3FF055300000048892D5400000049BB3747FB400100000041FFE366662E0F1F84000000000066662E0F1F84000000000066662E0F1F84000000000066662E0F1F84000000000066662E0F1F8400000000000F1F84000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
local OFF_CONTA = 0x1C0

local cave = nil
local visti = 0

local function L(s) log("[GUARDIA-ROSA] " .. s) end

local function dahex(h)
    return (string.gsub(h, "%x%x", function(x) return string.char(tonumber(x, 16)) end))
end

local function u64_le(n)
    local t = {}
    for i = 1, 8 do t[i] = string.char(n % 256); n = math.floor(n / 256) end
    return table.concat(t)
end

local function numerico(p)
    if type(p) == "number" then return p end
    return tonumber(ffi.cast("uint64_t", p))
end

local function controlla()
    if not cave then return end
    local c = memory.read(cave + OFF_CONTA, 4)
    if not c then return end
    local n = string.byte(c, 1) + string.byte(c, 2) * 256 + string.byte(c, 3) * 65536
    if n ~= visti then
        visti = n
        L(string.format("squadra vuota saltata: %d volte in questa sessione (crash evitati)", n))
    end
end

function m.set_teams(ctx) controlla() end
function m.after_set_conditions(ctx) controlla() end
function m.get_stadium_name(ctx, a, b, c) controlla(); return nil end

function m.init(ctx)
    L("v" .. m.version)
    if ffi == nil then L("luajit.ext non disponibile: non faccio niente"); return end
    for _, x in ipairs(SITI) do
        if memory.read(x.va, #x.originali) ~= x.originali then
            L(string.format("a 0x%X i byte non sono gli originali: versione del gioco diversa, non tocco niente", x.va))
            return
        end
    end
    ffi.cdef[[
    void* GuardiaRosa_VirtualAlloc(void* lpAddress, uint64_t dwSize,
        uint32_t flAllocationType, uint32_t flProtect) __asm__("VirtualAlloc");
    ]]
    local p = ffi.C.GuardiaRosa_VirtualAlloc(nil, 0x1000, 0x1000 + 0x2000, 0x40)
    if p == nil then L("memoria per il codecave non concessa: non faccio niente"); return end
    cave = numerico(p)
    local codice = dahex(CODICE_ESA)
    memory.write(cave, codice .. string.rep("\0", 16))
    if memory.read(cave, #codice) ~= codice then L("codecave rifiutato: non faccio niente"); cave = nil; return end
    for i, x in ipairs(SITI) do
        local salto = "\x49\xBB" .. u64_le(cave + x.cave) .. "\x41\xFF\xE3"
        salto = salto .. string.rep("\x90", #x.originali - #salto)
        memory.write(x.va, salto)
        if memory.read(x.va, #salto) ~= salto then
            for k = 1, i do memory.write(SITI[k].va, SITI[k].originali) end
            L("aggancio non riuscito: rimessi gli originali"); cave = nil; return
        end
    end
    L(string.format("ATTIVA su %d punti: una squadra senza giocatori non fa piu' chiudere il gioco", #SITI))
    ctx.register("set_teams", m.set_teams)
    ctx.register("after_set_conditions", m.after_set_conditions)
    ctx.register("get_stadium_name", m.get_stadium_name)
end

return m
