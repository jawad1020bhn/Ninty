--[[
================================================================================

        E C O N O M I A   L U N G A   -   M O T O R E

                              v0.1

   Michele & Claude  -  19 settembre 2026  -  eFootball PES 2021 + Sider 7.x

   --------------------------------------------------------------------------
   COS'E'
   --------------------------------------------------------------------------
   Non e' ancora una mod: e' il motore su cui la mod si costruira'. Da solo
   non cambia niente nel gioco. Quello che fa e' aprire la porta e tenerla
   aperta per i moduli che verranno dopo.

   Sa fare tre cose:

     1. trovare il blocco di memoria della Master League in corso
     2. trovare dentro quel blocco il record di un giocatore, dal suo codice
     3. leggere e scrivere i campi di quel record

   e mette tutto questo a disposizione degli altri moduli in  ctx.economia .

   --------------------------------------------------------------------------
   PERCHE' ESISTE
   --------------------------------------------------------------------------
   Fino a ieri la nostra sonda leggeva il puntatore dalla codecave di
   BudgetSetter. Funzionava, ma voleva dire dipendere da una mod di qualcun
   altro: spegni quella e si spegne tutto.

   Questo modulo il puntatore se lo cattura da solo. Se pero' trova che
   qualcun altro ha gia' agganciato quel punto con la stessa tecnica --
   BudgetSetter, o MLRuntime di Touchline -- non litiga: si appoggia al suo.

   --------------------------------------------------------------------------
   COME CI ARRIVA
   --------------------------------------------------------------------------
   Nel codice del gioco c'e' un punto dove il registro RDI contiene il
   puntatore a tutta la Master League:

       8B 87 F4 CB 6E 01     mov eax, [rdi + 0x016ECBF4]    <- il budget
       89 45 C4              mov [rbp-0x3C], eax
       48 8D 55 C4           lea rdx, [rbp-0x3C]
       48 8D 4D D0           lea rcx, [rbp-0x30]

   Diciassette byte. Li sostituiamo con un salto assoluto a una nostra
   paginetta di codice che fa una cosa sola in piu': si scrive RDI da parte.
   Poi esegue i diciassette originali e torna indietro. Il gioco non se ne
   accorge.

   Il merito della scoperta di questo punto e' di chi ha scritto BudgetSetter.
   Noi ci siamo arrivati leggendo la sua mod.

   --------------------------------------------------------------------------
   LA MAPPA, tutta verificata in partita il 18 e 19 settembre
   --------------------------------------------------------------------------

     blocco + 0                tabella giocatori
                               30.941 record da 380 byte (0x17C) in FL26

     dentro il record del giocatore:
       +0x02C    indice del record
       +0x030    codice giocatore   (ripetuto a +0x034)
       +0x038    nome mostrato                      ASCII
       +0x074    nome sulla maglia                  ASCII
       +0x0B0    nome per esteso                    ASCII
       +0x138    scadenza contratto   giorno | mese | anno
       +0x15C    stipendio annuale    unita' da 100
       +0x174    valore di mercato    unita' da 100
       +0x178    eta' (byte 0) | overall (byte 1)

     blocco + 0x1642A24        anno della carriera  (u16)
     blocco + 0x1642A26        mese                 (u8)
     blocco + 0x1642A27        giorno               (u8)
     blocco + 0x16ECBF4        budget trasferimenti unita' da 100
     blocco + 0x16ECC08        budget ingaggi       unita' da 100

   Le unita' sono sempre da 100: in memoria 155000 vuol dire 155.000 euro
   diviso... no: 1550 in memoria = 155.000 euro. Un'unita' = 100 euro.

   --------------------------------------------------------------------------
   TRAPPOLE DI SIDER  (pagate care, non ricascarci)
   --------------------------------------------------------------------------
   * pcall NON ESISTE. Nemmeno select. Un modulo che li chiama si spegne in
     silenzio dopo aver detto PROBLEM nel log.
   * memory.read su memoria non mappata NON restituisce nil: fa chiudere il
     gioco all'istante. Non andare mai a tentoni fuori da quello che sai buono.
     E il margine va lasciato SOTTO, non sopra: la finestra di ricerca finisce
     appena dopo il bilancio (0x16ECD00), non appena oltre. Con 0x1700000 il
     gioco e' crashato su una Master diversa, perche' i blocchi non sono tutti
     lunghi uguali.
   * memory.search_process guarda SOLO dentro l'exe del gioco, non nella
     memoria allocata dai moduli. Se un altro modulo ha gia' agganciato un
     punto, gli originali stanno nella sua codecave e da li' non si trovano.
     Per questo questo modulo va messo PRIMA degli altri nel sider.ini.
   * Gli indirizzi si scrivono in DECIMALE: tonumber("140000000",16) si ferma
     a 0xFFFFFFFF.
   * memory.search_process e memory.allocate_codecave restituiscono un
     PUNTATORE NATIVO, non un numero. Ci si fa aritmetica, ma NON si confronta
     con un numero: "attempt to compare 'unsigned char *' with 'number'" e il
     modulo si spegne. Per confrontare, leggi il valore con memory.unpack.
   * Mai un commento sulla stessa riga di un lua.module nel sider.ini.

================================================================================
]]

local m = { versione = "1.21" }
-- v1.21 (12/10/2026): i giri delle mod ospiti (Sorvegliante, Regole di
-- tesseramento, Frasi...) partivano solo con gli eventi set_teams /
-- after_set_conditions / get_stadium_name, che nei menu della Master non
-- arrivano: dopo un caricamento, finche' non si premeva "Avanti", le regole
-- non c'erano (Tsuchiya firmato alla Pro Vercelli) e la fama nemmeno. Adesso
-- li fa partire anche livecpk_make_key, che il gioco chiama a ogni file che
-- carica (anche nei menu: facce, stemmi). Al massimo una volta ogni 2
-- secondi, e restituisce sempre nil: non cambia nessun file.

-- ===========================================================================
--  COSTANTI
-- ===========================================================================

local FIRMA    = "\x8B\x87\xF4\xCB\x6E\x01\x89\x45\xC4\x48\x8D\x55\xC4\x48\x8D\x4D\xD0"
local PREFISSO = "\x48\x89\x3D\x29\x00\x00\x00"   -- mov [rip+0x29], rdi
local SALTO    = "\xFF\x25\x00\x00\x00\x00"       -- jmp qword [rip+0]
local OFF_DATO = 0x30

local RECORD      = 380
-- 8/10/2026 (v1.13): in Football Life 2026 la tabella ha 30.941 giocatori,
-- non i 30.001 della UML Steam (misurato con la sonda il 5/10: 30.941 record
-- contigui da 380 byte). Con 30001 la ricerca per codice non vedeva gli
-- ultimi ~940, cioe' buona parte dei campionati aggiunti. 30.941 x 380 =
-- 11,8 MB: ben dentro FINESTRA.
local N_GIOCATORI = 30941
local FINE_TAB    = N_GIOCATORI * RECORD
-- v1.20 (8/10/2026): il numero dei giocatori non e' piu' fisso. Il gioco lo
-- tiene nel blocco a +0x03B2087C (lo usa lui stesso nei giri sulla tabella,
-- es. 0x140FAC36B "cmp esi,[rbx+3B2087Ch]"). Con la Serie C sono 31.306.
-- Lo rileggo ogni volta che il blocco viene trovato; se il numero e' strano
-- resto sull'ultimo buono.
local OFF_QUANTI_GIOC = 0x03B2087C
local function aggiorna_quanti(b)
  local s = memory.read(b + OFF_QUANTI_GIOC, 4)
  if not s or #s ~= 4 then return end
  local n = memory.unpack("u32", s)
  n = tonumber(n)
  if n and n >= 1000 and n <= 0xCA11 and n ~= N_GIOCATORI then
    N_GIOCATORI = n
    FINE_TAB = N_GIOCATORI * RECORD
    log("[EconomiaLunga] giocatori nella tabella: " .. n)
  end
end

local O_INDICE   = 0x02C
local O_CODICE   = 0x030
local O_NOME     = 0x038
local O_CONTR    = 0x138
local O_STIP     = 0x15C
local O_VALORE   = 0x174
local O_ETAOV    = 0x178

local B_ANNO     = 0x1642A24
local B_MESE     = 0x1642A26
local B_GIORNO   = 0x1642A27
local B_TRASF    = 0x016ECBF4
local B_INGAGGI  = 0x016ECC08

-- 19/9: con 0x1700000 il gioco e' crashato sulla Master del City. Quel limite
-- stava appena OLTRE l'ultima casella che sappiamo esistere (il bilancio, a
-- 0x16ECC28), quindi il margine era zero e bastava un blocco allocato un filo
-- piu' corto per uscire fuori. Adesso ci si ferma PRIMA, subito dopo il
-- bilancio. NON alzarlo.
--
-- E sta QUI, in cima, non a meta' file: una local in Lua vale solo da dove e'
-- scritta in giu'. Dichiarata a meta' file era nil per tutto il codice sopra,
-- e la ricerca della rosa moriva con "attempt to compare number with nil".
local FINESTRA = 0x16ECD00

-- ===========================================================================

local hook_addr, cave_addr, dato_addr = nil, nil, nil
local nostro_aggancio = false
local diagnosi = "non avviato"
local ultimo_overlay = 0
local cache = {}          -- codice giocatore -> indirizzo del record

local function L(t) log("[EconomiaLunga] " .. t) end

local function euro(u)
  if not u then return "?" end
  local s = tostring(math.floor(u) * 100)
  while true do
    local k
    s, k = string.gsub(s, "^(-?%d+)(%d%d%d)", "%1.%2")
    if k == 0 then break end
  end
  return s
end

-- pcall non esiste: memory.read torna nil quando non riesce
local function leggi(a, n)
  local s = memory.read(a, n)
  if not s or #s ~= n then return nil end
  return s
end

local function u8(a)  local s = leggi(a,1); return s and memory.unpack("u8",  s) end
local function u16(a) local s = leggi(a,2); return s and memory.unpack("u16", s) end
local function u32(a) local s = leggi(a,4); return s and memory.unpack("u32", s) end
local function u64(a) local s = leggi(a,8); return s and memory.unpack("u64", s) end

local function scrivi32(a, v)
  memory.write(a, memory.pack("u32", v))
  return u32(a) == v
end

-- ===========================================================================
--  L'AGGANCIO
-- ===========================================================================

local function adotta_aggancio_esistente()
  -- Qualcun altro ha gia' messo un salto qui? Se e' una cattura compatibile,
  -- ci appoggiamo alla sua invece di litigare.
  local ora = leggi(hook_addr, 6)
  if ora ~= SALTO then return false end
  -- qui c viene da memory.unpack, quindi e' un numero vero: il confronto si puo' fare
  local c = u64(hook_addr + 6)
  if not c or c <= 0x10000 then return false end
  if leggi(c, 7) ~= PREFISSO then
    diagnosi = "quel punto e' gia' agganciato da qualcosa che non riconosco"
    return false
  end
  cave_addr = c
  dato_addr = c + OFF_DATO
  nostro_aggancio = false
  diagnosi = "mi appoggio a un aggancio gia' presente (" .. memory.hex(c) .. ")"
  return true
end

local function installa_aggancio()
  local c = memory.allocate_codecave(128)
  -- ATTENZIONE: allocate_codecave (come search_process) restituisce un
  -- PUNTATORE NATIVO, non un numero. Confrontarlo con 0x10000 fa fallire il
  -- modulo con "attempt to compare 'unsigned char *' with 'number'".
  -- Sui puntatori si fa aritmetica, non confronti.
  if not c then
    diagnosi = "non sono riuscito ad allocare la codecave"
    return false
  end
  local ritorno = hook_addr + 17
  -- la paginetta:  salva RDI  /  i 17 byte originali  /  torna indietro
  local codice = PREFISSO .. FIRMA .. SALTO .. memory.pack("u64", ritorno)
  memory.write(c, codice)
  -- la memoria appena allocata non e' garantita a zero: azzeriamo lo slot,
  -- cosi' nessuno legge un puntatore inventato prima che il gioco ci passi
  memory.write(c + OFF_DATO, memory.pack("u64", 0))
  -- e adesso il salto, con tre nop per coprire i 17 byte tondi
  memory.write(hook_addr, SALTO .. memory.pack("u64", c) .. "\x90\x90\x90")
  cave_addr = c
  dato_addr = c + OFF_DATO
  nostro_aggancio = true
  diagnosi = "aggancio installato da noi, codecave a " .. memory.hex(c)
  return true
end

local function prepara()
  if dato_addr then return true end
  hook_addr = memory.search_process(FIRMA)
  if hook_addr then
    L("i 17 byte sono a " .. memory.hex(hook_addr) .. ", intatti")
    return installa_aggancio()
  end
  -- non trovati: o la versione e' diversa, o qualcuno ha gia' agganciato.
  -- Non possiamo cercare la sua codecave (search_process non ci arriva), ma
  -- se il modulo e' caricato per primo questo caso non capita.
  diagnosi = "i 17 byte non si trovano nell'exe: mettimi PRIMA degli altri "
          .. "moduli nel sider.ini, oppure la versione del gioco e' diversa"
  return false
end

-- ===========================================================================
--  L'INTERFACCIA PER GLI ALTRI MODULI
-- ===========================================================================

local api = { versione = m.versione }

-- ---------------------------------------------------------------------------
--  v1.19 (8/10/2026): IL VERO MOTIVO DEL CRASH 0x2FF8. Il motore agganciava
--  gli eventi con funzioni "volanti", scritte dentro la chiamata:
--      ctx.register("set_teams", function(ctx) ... end)
--  Sider non le tiene da nessuna parte: appena Lua fa pulizia della memoria
--  (al caricamento della carriera, quando le altre mod scrivono migliaia di
--  righe) quelle funzioni spariscono, e quando Sider prova a chiamarle il
--  gioco crolla dentro sider.dll, sempre a 0x2FF8. Infatti nessuna delle
--  altre 80 mod della UML lo fa: tutte agganciano funzioni che stanno nella
--  tabella del modulo. Adesso anche il motore: m.set_teams,
--  m.after_set_conditions, m.get_stadium_name.
--
--  v1.18 (8/10/2026): PRONTA SOLO A CARRIERA FERMA. Il crash dentro
--  sider.dll (0x2FF8, sempre lo stesso) arrivava mentre la carriera si stava
--  ancora CARICANDO: il puntatore fisso trova gia' il blocco con una data
--  valida, ma il gioco lo sta ancora costruendo, e chi legge le zone in fondo
--  (le rose, a +0x16Bxxxx) trova memoria non ancora mappata. Adesso
--  api.pronta() dice di si' solo quando lo stesso blocco e' rimasto al suo
--  posto per 20 secondi. Tutte le mod che chiedono pronta() aspettano.
--
--  v1.17 (8/10/2026): IL CENTRALINO DEGLI EVENTI. Sider ha un limite al
--  numero di funzioni che si possono agganciare allo stesso evento: oltre una
--  quarantina di "set_teams" il gioco crolla dentro sider.dll (sempre allo
--  stesso punto, 0x2FF8), come succedeva con l'overlay. Adesso il motore
--  aggancia UNA volta set_teams, after_set_conditions e get_stadium_name e
--  chiama lui le nostre mod che si sono iscritte con
--      eco.registra_giro(funzione)
--  Cosi' cinque mod occupano tre posti invece di quindici.
--
--  v1.16 (8/10/2026): LA ROSA SI RICERCA OGNI GIORNO DI CARRIERA. Prima la
--  posizione della tabella delle prestazioni veniva trovata una volta e
--  tenuta per sempre: dopo le cessioni di gennaio il Sorvegliante ha letto
--  "la tua rosa, 2" invece di 20, segno che la tabella si era spostata e
--  noi leggevamo ancora il posto vecchio. Adesso la si ricerca quando cambia
--  la data, e il log dice quanti giocatori vede e quanti di questi sono
--  davvero del tuo club. Nuova api.squadra(): l'ID del tuo club (lo stesso
--  modo delle mod dei prestiti: forma grezza / 16384).
--  Prova in partita (8/10): rosa di 20 a video, la tabella ne dava 17 di
--  fila. Gli altri 3 hanno la loro riga delle prestazioni da un'altra parte:
--  adesso api.rosa() prende dalla scheda di ogni giocatore chi gioca nel tuo
--  club e va a cercare la riga di chi manca (indice + codice, 8 byte esatti).
--
--  v1.15 (8/10/2026): i messaggi del blocco scrivevano un indirizzo a 64 bit
--  con %X e il gioco dava "bad argument #2 to 'format'": ora lo converto.
--
--  v1.14 (8/10/2026): IL BLOCCO SI TROVA ANCHE SENZA PASSARE DAI TRASFERIMENTI
-- ---------------------------------------------------------------------------
--  Prima il blocco arrivava SOLO dall'aggancio sul budget, cioe' solo dopo
--  essere passati dalla schermata trasferimenti in quella sessione: senza quel
--  passaggio il Sorvegliante e la rivalutazione automatica restavano fermi.
--  Adesso, se l'aggancio non l'ha ancora preso, il blocco si legge dal
--  puntatore fisso del gioco al "manager" della carriera, la stessa strada che
--  usa da settimane il Rientro dai prestiti:
--      blocco = [[statica] + 0x48]
--  con la statica a 0x143705E10 in FL26 e a 0x143714240 in PES 2021 Steam.
--  Quale delle due lo dice l'accessore del gioco che la legge (mov rax,[rip+x]
--  / ret): si controllano i suoi otto byte, e se non sono nessuno dei due la
--  strada nuova resta chiusa. Il blocco trovato cosi' viene accettato solo se
--  la data della carriera dentro e' una data vera.

local STATICA = nil        -- nil = non ancora deciso, false = eseguibile sconosciuto

local function statica()
  if STATICA ~= nil then return STATICA end
  local fl = leggi(0x140000000 + 0x014B6A60, 8)
  local st = leggi(0x140000000 + 0x014BC550, 8)
  if fl == "\x48\x8B\x05\xA9\xF3\x24\x02\xC3" then
    STATICA = 0x143705E10
    L("blocco: profilo Football Life 2026, puntatore fisso a 0x143705E10")
  elseif st == "\x48\x8B\x05\xE9\x7C\x25\x02\xC3" then
    STATICA = 0x143714240
    L("blocco: profilo PES 2021 Steam, puntatore fisso a 0x143714240")
  else
    STATICA = false
    L("blocco: eseguibile non riconosciuto, il blocco arrivera' solo dai trasferimenti")
  end
  return STATICA
end

local function blocco_statico()
  local s = statica()
  if not s then return nil end
  local manager = u64(s)
  if not manager or manager <= 0x10000 then return nil end
  local b = u64(manager + 0x48)
  if not b or b <= 0x10000 then return nil end
  local anno, mese, giorno = u16(b + B_ANNO), u8(b + B_MESE), u8(b + B_GIORNO)
  if not anno or anno < 2000 or anno > 2200 or not mese or mese < 1 or mese > 12
     or not giorno or giorno < 1 or giorno > 31 then
    return nil
  end
  return b
end

local avvisato_statico = false
local confrontati = false

function api.blocco()
  if dato_addr then
    local b = u64(dato_addr)
    if b and b > 0x10000 then
      if not confrontati then
        -- la prima volta che ci sono tutte e due le strade, le confronto
        confrontati = true
        local b2 = blocco_statico()
        if b2 == b then
          L(string.format("blocco 0x%X: l'aggancio e il puntatore fisso coincidono", tonumber(b)))
        else
          L(string.format("ATTENZIONE: aggancio 0x%X, puntatore fisso %s: NON coincidono",
            tonumber(b), b2 and string.format("0x%X", tonumber(b2)) or "nessuno"))
        end
      end
      return b
    end
  end
  local b = blocco_statico()
  if b and not avvisato_statico then
    avvisato_statico = true
    L(string.format("blocco trovato dal puntatore fisso: 0x%X (senza passare dai trasferimenti)", tonumber(b)))
  end
  return b
end

local stabile_b, stabile_t = nil, 0
local quanti_letti_per = nil
local ATTESA_STABILE = 20     -- secondi
function api.pronta()
  local b = api.blocco()
  if b == nil then stabile_b = nil; return false end
  local n = tonumber(b)
  if n ~= stabile_b then
    stabile_b, stabile_t = n, os.clock()
    return false
  end
  if os.clock() - stabile_t < ATTESA_STABILE then return false end
  -- carriera ferma da 20 secondi: ora si puo' leggere il numero dei giocatori
  if not quanti_letti_per or quanti_letti_per ~= n then
    quanti_letti_per = n
    aggiorna_quanti(b)
  end
  return true
end

function api.data()
  local b = api.blocco(); if not b then return nil end
  return u8(b + B_GIORNO), u8(b + B_MESE), u16(b + B_ANNO)
end

function api.budget()
  local b = api.blocco(); if not b then return nil end
  return u32(b + B_TRASF), u32(b + B_INGAGGI)
end

-- Trova il record di un giocatore dal suo codice. Scorre la tabella a blocchi
-- e accetta solo gli allineamenti veri, cosi' un numero uguale che capita per
-- caso dentro un altro campo non ci frega.
function api.record(codice)
  local b = api.blocco(); if not b then return nil end
  if cache[codice] then return cache[codice] end
  local pat = memory.pack("u32", codice)
  local pos = 0
  while pos < FINE_TAB do
    local quanti = 0x10000
    if pos + quanti > FINE_TAB then quanti = FINE_TAB - pos end
    local dati = leggi(b + pos, quanti + 3)
    if dati then
      local da = 1
      while true do
        local a = string.find(dati, pat, da, true)
        if not a then break end
        local off = pos + a - 1
        if off >= O_CODICE and (off - O_CODICE) % RECORD == 0
           and u32(b + off + 4) == codice then   -- il codice e' ripetuto a +0x034
          cache[codice] = b + off - O_CODICE
          return cache[codice]
        end
        da = a + 1
      end
    end
    pos = pos + 0x10000
  end
  return nil
end

function api.nome(r)
  local s = leggi(r + O_NOME, 60)
  if not s then return "?" end
  local fine = string.find(s, "\0", 1, true)
  if fine then s = string.sub(s, 1, fine - 1) end
  return s
end

function api.leggi_giocatore(codice)
  local r = api.record(codice); if not r then return nil end
  local eo = leggi(r + O_ETAOV, 2)
  local c  = u32(r + O_CONTR)
  local g = { indirizzo = r, codice = codice }
  g.nome      = api.nome(r)
  g.indice    = u32(r + O_INDICE)
  g.stipendio = u32(r + O_STIP)
  g.valore    = u32(r + O_VALORE)
  g.eta       = eo and string.byte(eo, 1) or nil
  g.overall   = eo and string.byte(eo, 2) or nil
  if c then
    g.contratto      = c
    g.contratto_anno   = c % 65536
    g.contratto_mese   = math.floor(c / 65536) % 256
    g.contratto_giorno = math.floor(c / 16777216) % 256
  end
  return g
end

-- Scritture. Ognuna rilegge e dice se ha tenuto.
-- ===========================================================================
--  LA TABELLA DELLE PRESTAZIONI  --  trovata da sola
-- ===========================================================================
--
--  Record da 44 byte: [u32 indice][u32 codice][3 gruppi da sei u16].
--  La si riconosce cosi': tre record di fila con l'indice che cresce di uno,
--  e il codice del primo che coincide con quello che la tabella grande dei
--  giocatori ha a quell'indice. Con quel controllo incrociato non ci sono
--  falsi positivi.
--
--  La ricerca parte dalla zona dove l'abbiamo vista (0x1600000 in su) e se
--  non trova niente allarga. Sempre dentro FINESTRA: fuori il gioco si
--  chiude, non torna nil.

local R_REC = 44
local R_COD = 0x04
local R_GRUPPI = { campionato = 0x08, coppe = 0x14, totale = 0x20 }

local rosa_off = nil

local function tre_di_fila(s, p, base)
  if string.byte(s, p + 3) ~= 0 then return nil end
  local b3 = string.byte(s, p + 2)
  if not b3 or b3 > 0x75 then return nil end
  local i0 = string.byte(s,p) + string.byte(s,p+1)*256 + b3*65536
  if i0 < 1 or i0 > N_GIOCATORI then return nil end
  local q1, q2 = p + R_REC, p + 2*R_REC
  if q2 + 7 > #s then return nil end
  local i1 = string.byte(s,q1) + string.byte(s,q1+1)*256 + string.byte(s,q1+2)*65536
  if string.byte(s,q1+3) ~= 0 or i1 ~= i0 + 1 then return nil end
  local i2 = string.byte(s,q2) + string.byte(s,q2+1)*256 + string.byte(s,q2+2)*65536
  if string.byte(s,q2+3) ~= 0 or i2 ~= i0 + 2 then return nil end
  -- controllo incrociato col database in memoria
  local c0 = string.byte(s,p+4) + string.byte(s,p+5)*256
           + string.byte(s,p+6)*65536 + string.byte(s,p+7)*16777216
  local vero = u32(base + i0 * RECORD + O_CODICE)
  if not vero or vero ~= c0 then return nil end
  return i0
end

local function cerca_rosa(base, da)
  local pos = da
  while pos < FINESTRA do
    local quanti = 0x10000
    if pos + quanti > FINESTRA then quanti = FINESTRA - pos end
    local extra = 2 * R_REC + 8
    if pos + quanti + extra > FINESTRA then extra = FINESTRA - pos - quanti end
    local s = leggi(base + pos, quanti + extra)
    if s then
      for p = 1, quanti, 4 do
        if tre_di_fila(s, p, base) then
          return pos + p - 1
        end
      end
    end
    pos = pos + 0x10000
  end
  return nil
end

local rosa_data = nil      -- la data di carriera in cui rosa_off e' stato trovato
local rosa_contati = nil  -- quanti giocatori ha dato l'ultima volta (per il log)

function api.squadra()
  local base = api.blocco()
  if not base then return nil end
  local grezza = u32(base + 0x01642A2C)
  if not grezza or grezza == 0xFFFFFFFF then return nil end
  return math.floor(grezza / 16384)
end

function api.tabella_rosa()
  local base = api.blocco()
  if not base then return nil end
  local a, me, g = u16(base + B_ANNO), u8(base + B_MESE), u8(base + B_GIORNO)
  local oggi = (a or 0) * 10000 + (me or 0) * 100 + (g or 0)
  if rosa_off and rosa_data == oggi then return rosa_off end
  rosa_off = nil
  rosa_data = oggi
  local o = cerca_rosa(base, 0x1600000)
  if not o then o = cerca_rosa(base, 0x1000000) end
  if not o then return nil end
  -- torna all'inizio: indietro finche' gli indici scendono di uno
  while o - R_REC >= 0 do
    local a = u32(base + o - R_REC)
    local b = u32(base + o)
    if not a or not b or a ~= b - 1 then break end
    o = o - R_REC
  end
  rosa_off = o
  return o
end

-- i giocatori che giocano nel tuo club, letti dalle schede: codice -> indice
local function giocatori_del_club(base, sq)
  local t, n = {}, 0
  local PEZZO = 4000
  local i = 0
  while i < N_GIOCATORI do
    local q = PEZZO
    if i + q > N_GIOCATORI then q = N_GIOCATORI - i end
    local d = leggi(base + i * RECORD, q * RECORD)
    if not d then break end
    for k = 0, q - 1 do
      local o = k * RECORD
      local cod = memory.unpack("u32", string.sub(d, o + O_CODICE + 1, o + O_CODICE + 4))
      local c = memory.unpack("u32", string.sub(d, o + 0x12C + 1, o + 0x12C + 4))
      if cod ~= 0 and c ~= 0xFFFFFFFF and math.floor(c / 16384) == sq then
        t[cod] = i + k; n = n + 1
      end
    end
    i = i + q
  end
  return t, n
end

-- la riga delle prestazioni di un giocatore: [u32 indice][u32 codice]
local function cerca_riga(base, indice, codice)
  local pat = memory.pack("u32", indice) .. memory.pack("u32", codice)
  for _, z in ipairs({ { 0x1600000, FINESTRA }, { 0x1000000, 0x1600000 } }) do
    local pos = z[1]
    while pos < z[2] do
      local q = 0x10000
      if pos + q > z[2] then q = z[2] - pos end
      local extra = 7
      if pos + q + extra > FINESTRA then extra = FINESTRA - pos - q end
      local d = leggi(base + pos, q + extra)
      if d then
        local a = string.find(d, pat, 1, true)
        if a then return pos + a - 1 end
      end
      pos = pos + q
    end
  end
  return nil
end

local rosa_cache, rosa_cache_data = nil, nil

local function riga_rosa(base, p)
  local idx = u32(base + p)
  local cod = u32(base + p + R_COD)
  if not idx or not cod or idx > N_GIOCATORI or cod == 0 or cod > 400000 then return nil end
  local g = leggi(base + p + R_GRUPPI.totale, 12)
  if not g then return nil end
  local v = {}
  for k = 1, 6 do v[k] = memory.unpack("u16", string.sub(g, k*2-1, k*2)) end
  return { indice = idx, codice = cod, offset = p,
           partite_squadra = v[1], presenze = v[2],
           gol = v[3], assist = v[4], voti = v[6],
           -- somma dei voti x10: diviso le presenze da' il voto medio
           minuti = v[6] }
end

function api.rosa()
  local base = api.blocco()
  local o = api.tabella_rosa()
  if not base or not o then return nil end
  if rosa_cache and rosa_cache_data == rosa_data then return rosa_cache end
  local out = {}
  local p = o
  while #out < 200 do
    if p + R_REC > FINESTRA then break end
    local x = riga_rosa(base, p)
    if not x then break end
    out[#out+1] = x
    p = p + R_REC
  end
  -- v1.16: chi gioca nel tuo club ma non e' nel blocco di fila
  local sq = api.squadra()
  local aggiunti, mancanti = 0, 0
  if sq then
    local club = giocatori_del_club(base, sq)
    for _, x in ipairs(out) do club[x.codice] = nil end
    for cod, idx in pairs(club) do
      local p = cerca_riga(base, idx, cod)
      local x = p and riga_rosa(base, p)
      if x then out[#out+1] = x; aggiunti = aggiunti + 1
      else mancanti = mancanti + 1 end
    end
  end
  rosa_cache, rosa_cache_data = out, rosa_data
  if #out ~= rosa_contati then
    rosa_contati = #out
    if aggiunti > 0 or mancanti > 0 then
      L(string.format("rosa: %d trovati fuori dal blocco di fila, %d del tuo club senza riga delle prestazioni",
        aggiunti, mancanti))
    end
    -- quanti sono davvero del tuo club (dove gioca o chi e' il padrone)
    local miei = 0
    if sq then
      for _, x in ipairs(out) do
        local r = api.record(x.codice)
        if r then
          local c, pd = u32(r + 0x12C), u32(r + 0x160)
          if (c and c ~= 0xFFFFFFFF and math.floor(c / 16384) == sq)
             or (pd and pd ~= 0xFFFFFFFF and math.floor(pd / 16384) == sq) then
            miei = miei + 1
          end
        end
      end
    end
    L(string.format("rosa: %d giocatori nella tabella delle prestazioni (+0x%X), %d del tuo club (ID %s)",
      #out, o, miei, tostring(sq)))
  end
  return out
end

-- ===========================================================================
--  IL CENTRALINO DEI TASTI
-- ===========================================================================
--
--  19 settembre, sera. Un modulo separato registrava il suo tasto con
--  ctx.register("key_down", ...) e non riceveva NIENTE: ne' la lettera che
--  aspettava ne' le cifre. La spia dei tasti, accesa apposta, non ha
--  registrato un solo tasto.
--
--  Sider manda i tasti al modulo la cui PAGINA dell'overlay e' quella
--  visibile in quel momento, e con venti moduli che registrano overlay_on
--  quella pagina non la si raggiunge mai.
--
--  Quindi il motore fa da centralino: gli altri moduli gli lasciano qui il
--  loro tasto, e lui li chiama dalla SUA pagina, che si raggiunge.
--
--      eco.registra_tasto(0x52, "R", "prova la rivalutazione", funzione)

local tasti_ospiti = {}

local giri = {}
function api.registra_giro(fn)
  giri[#giri + 1] = fn
end
local function fai_giri()
  for i = 1, #giri do giri[i]() end
end

function api.registra_tasto(vkey, etichetta, descrizione, fn)
  tasti_ospiti[vkey] = { etichetta = etichetta, descrizione = descrizione, fn = fn }
  L("tasto ospite registrato: " .. tostring(etichetta) .. " -> " .. tostring(descrizione))
  return true
end

function api.scrivi_stipendio(codice, unita)
  local r = api.record(codice); if not r then return false end
  return scrivi32(r + O_STIP, unita)
end

function api.scrivi_valore(codice, unita)
  local r = api.record(codice); if not r then return false end
  if unita < 120 then unita = 120 end        -- sotto 120 il gioco lo rifiuta
  return scrivi32(r + O_VALORE, unita)
end

function api.scrivi_contratto(codice, giorno, mese, anno)
  local r = api.record(codice); if not r then return false end
  local v = anno + mese * 65536 + giorno * 16777216
  return scrivi32(r + O_CONTR, v)
end

function api.scrivi_budget(trasferimenti, ingaggi)
  local b = api.blocco(); if not b then return false end
  local ok = true
  if trasferimenti then ok = scrivi32(b + B_TRASF, trasferimenti) and ok end
  if ingaggi       then ok = scrivi32(b + B_INGAGGI, ingaggi) and ok end
  return ok
end

-- ===========================================================================
--  OVERLAY  (solo informativo, non fa niente)
-- ===========================================================================

-- un giocatore qualsiasi da mostrare come prova che il motore gira
local CAMPIONE = 133543          -- E. Haaland
local NOME_CAMPIONE = "Haaland"

-- ===========================================================================
--  PROVA: il tetto dell'offerta segue il valore?
-- ===========================================================================
--
--  In partita il cursore del costo di trasferimento si ferma esattamente
--  sulla clausola rescissoria, e la clausola e' un multiplo del valore di
--  mercato. Se la catena e' questa:
--
--       valore  ->  clausola  ->  quanto puoi offrire
--
--  allora moltiplicando il valore per dieci deve salire tutto.
--
--  Tasto 5 = moltiplica per 10.  Tasto 6 = rimette com'era.

local PROVA_CODICE = 168632      -- Inigo Arguibide, CA Osasuna
local PROVA_NOME   = "Arguibide"
local PROVA_FATT   = 10
local prova_originale = nil
local prova_stato = "non provata"

local function prova_scrivi()
  local g = api.leggi_giocatore(PROVA_CODICE)
  if not g or not g.valore then prova_stato = "non lo trovo" return end
  if prova_originale == nil then prova_originale = g.valore end
  local nuovo = prova_originale * PROVA_FATT
  L("")
  L("=== PROVA VALORE: " .. PROVA_NOME .. " ===")
  L("  prima  " .. euro(prova_originale))
  L("  scrivo " .. euro(nuovo))
  if api.scrivi_valore(PROVA_CODICE, nuovo) then
    local g2 = api.leggi_giocatore(PROVA_CODICE)
    L("  riletto " .. euro(g2 and g2.valore))
    L("  adesso vai a fargli un'offerta e guarda dove si ferma il cursore.")
    prova_stato = "SCRITTO " .. euro(nuovo) .. " - guarda l'offerta, poi 6"
  else
    L("  la scrittura non ha tenuto")
    prova_stato = "scrittura non riuscita"
  end
end

local function prova_rimetti()
  if prova_originale == nil then prova_stato = "niente da rimettere" return end
  if api.scrivi_valore(PROVA_CODICE, prova_originale) then
    L("rimesso il valore originale: " .. euro(prova_originale))
    prova_stato = "RIMESSO " .. euro(prova_originale)
  else
    prova_stato = "non sono riuscito a rimetterlo: chiudi senza salvare"
  end
end


-- ===========================================================================
--  RICERCA DEL BILANCIO DEL CLUB   (tasto 7)
-- ===========================================================================
--
--  Il gioco mostra il bilancio stagionale del club: diritti tv, sponsor,
--  tifosi, merchandising, botteghino, premi, ingaggi. Sono sette voci, e se
--  sono caselle in memoria allora il prestigio economico dei club lo
--  possiamo riscrivere noi.
--
--  Questi numeri vengono da CA BARRACAS CENTRAL, Master del 19 settembre.
--  In un'altra carriera cambiano: rileggi il bilancio e riscrivili qui,
--  sempre in unita' da cento (euro diviso 100).
--
--  Meglio i numeri storti: 16003 e 31701 compaiono una volta sola in
--  ventitre' megabyte, 1000 compare dappertutto e non serve a niente.

local BILANCIO = {
  { nome = "diritti tv",       valore = 16003 },   --  1.600.300
  { nome = "sponsorizzazioni", valore = 30670 },   --  3.067.000
  { nome = "club di tifosi",   valore = 31701 },   --  3.170.100
  { nome = "ingaggi totali",   valore = 66019 },   --  6.601.900
  { nome = "budget ingaggi",   valore =  1582 },   --    158.200
}

-- 19/9: con 0x1700000 il gioco e' crashato sulla Master del City. Quel limite
-- stava appena OLTRE l'ultima casella che sappiamo esistere (il bilancio, a
-- 0x16ECC28), quindi il margine era zero e bastava un blocco allocato un filo
-- piu' corto per uscire fuori. Adesso ci si ferma PRIMA, subito dopo il
-- bilancio. Copre comunque tutta la tabella dei giocatori (0 - 0xADF33C) e
-- tutta l'area finanziaria. NON alzarlo.
local TETTO_HIT = 80
local bilancio_stato = "non cercato"

local function cerca_bilancio()
  local base = api.blocco()
  if not base then bilancio_stato = "nessuna Master aperta" return end

  local bers = {}
  for i = 1, #BILANCIO do
    bers[i] = { nome = BILANCIO[i].nome, val = BILANCIO[i].valore,
                pat = memory.pack("u32", BILANCIO[i].valore), hit = {}, troppi = false }
  end

  local pos = 0
  while pos < FINESTRA do
    local quanti = 0x10000
    local extra  = 3
    if pos + quanti > FINESTRA then quanti = FINESTRA - pos; extra = 0 end
    local dati = leggi(base + pos, quanti + extra)
    if dati then
      for i = 1, #bers do
        local b = bers[i]
        if not b.troppi then
          local da = 1
          while true do
            local a = string.find(dati, b.pat, da, true)
            if not a then break end
            local off = pos + a - 1
            if off < FINESTRA then
              b.hit[#b.hit + 1] = off
              if #b.hit >= TETTO_HIT then b.troppi = true; break end
            end
            da = a + 1
          end
        end
      end
    end
    pos = pos + 0x10000
  end

  L("")
  L("================================================================")
  L("RICERCA DEL BILANCIO DEL CLUB")
  L("================================================================")
  L("taratura: il budget trasferimenti sta a +0x016ECBF4 e vale "
    .. euro(u32(base + B_TRASF)))
  L("")
  local buoni = {}
  for i = 1, #bers do
    local b = bers[i]
    L(string.format("%-18s %d   (%s euro)", b.nome, b.val, euro(b.val)))
    if #b.hit == 0 then
      L("     non trovato")
    else
      L(string.format("     trovato %d volte%s", #b.hit,
        b.troppi and " (fermato al tetto)" or ""))
      local n = #b.hit
      if n > 10 then n = 10 end
      for j = 1, n do
        L(string.format("     +0x%08X", b.hit[j]))
      end
      if #b.hit > n then L(string.format("     ... e altre %d", #b.hit - n)) end
      if not b.troppi then buoni[#buoni + 1] = b end
    end
    L("")
  end

  L("----------------------------------------------------------------")
  L("DISTANZE fra i primi risultati")
  L("se le sette voci stanno in un record, sono vicine fra loro")
  L("----------------------------------------------------------------")
  for i = 1, #buoni do
    for j = i + 1, #buoni do
      L(string.format("  %-18s -> %-18s  %+d byte",
        buoni[i].nome, buoni[j].nome, buoni[j].hit[1] - buoni[i].hit[1]))
    end
  end
  L("")

  if #buoni > 0 then
    local b = buoni[1]
    local o = b.hit[1]
    L("----------------------------------------------------------------")
    L(string.format("VICINATO di %s, a +0x%08X", b.nome, o))
    L("----------------------------------------------------------------")
    for k = -16, 16 do
      local v = u32(base + o + k * 4)
      if v then
        L(string.format("   %+5d  %14.0f  %s", k * 4, v, (k == 0) and "<== cercato" or ""))
      end
    end
    L("")
  end
  L("FINE")
  bilancio_stato = "FATTA - guarda sider.log, cerca EconomiaLunga"
end


-- ===========================================================================
--  IL BILANCIO DEL CLUB   (tasto 8)
-- ===========================================================================
--
--  Trovato il 19 settembre cercando i numeri del bilancio del CA Barracas
--  Central. Tre voci in fila, attaccate ai due budget:
--
--     +0x016ECBF4   budget trasferimenti
--     +0x016ECC08   tetto degli ingaggi
--     +0x016ECC20   diritti tv
--     +0x016ECC24   sponsorizzazioni
--     +0x016ECC28   club di tifosi
--
--  Il resto delle voci deve stare li' intorno. Questo tasto legge tutta la
--  finestra e la stampa, cosi' si battezzano le caselle rimaste confrontando
--  con quello che si legge nella schermata "Bilancio conto club".
--
--  Gli ingaggi totali NON ci sono: quelli il gioco li somma dai giocatori.

local FIN_DA  = 0x016ECB80
local FIN_A   = 0x016ECC80

local function dump_bilancio()
  local base = api.blocco()
  if not base then bilancio_stato = "nessuna Master aperta" return end
  L("")
  L("================================================================")
  L("FINESTRA DEL BILANCIO DEL CLUB")
  L("================================================================")
  L("confronta con la schermata Bilancio conto club: le cifre a video")
  L("sono queste x100.")
  L("")
  local o = FIN_DA
  while o <= FIN_A do
    local v = u32(base + o)
    if v then
      local nota = ""
      if o == 0x016ECBF4 then nota = "  <- budget trasferimenti" end
      if o == 0x016ECC08 then nota = "  <- tetto ingaggi" end
      if o == 0x016ECC20 then nota = "  <- diritti tv" end
      if o == 0x016ECC24 then nota = "  <- sponsorizzazioni" end
      if o == 0x016ECC28 then nota = "  <- club di tifosi" end
      L(string.format("  +0x%07X  %12.0f  = %s euro%s", o, v, euro(v), nota))
    end
    o = o + 4
  end
  L("")
  L("FINE")
  bilancio_stato = "finestra letta - guarda sider.log"
end


-- ===========================================================================
--  PROVA TIFOSI   (tasto 9 moltiplica per 10, tasto 0 rimette)
-- ===========================================================================
--
--  L'entrata "Club di tifosi" del CA Barracas Central e' 3.170.100 euro, e il
--  contatore dei follower a destra nella schermata principale dice 31.701.
--  Lo stesso identico numero: un follower = cento euro.
--
--  Se e' cosi', +0x16ECC28 non e' un'entrata: e' il numero di tifosi. E il
--  prestigio di un club diventa una cosa che cresce quando vinci, invece di
--  un numero fisso deciso alla nascita della Master.

local O_TIFOSI   = 0x016ECC28
local TIFOSI_FAT = 10
local tifosi_orig = nil
local tifosi_stato = "non provata"

local function tifosi_scrivi()
  local b = api.blocco()
  if not b then tifosi_stato = "nessuna Master aperta" return end
  local ora = u32(b + O_TIFOSI)
  if not ora then tifosi_stato = "non riesco a leggere" return end
  if tifosi_orig == nil then tifosi_orig = ora end
  local nuovo = tifosi_orig * TIFOSI_FAT
  L("")
  L("=== PROVA TIFOSI ===")
  L("  prima  " .. tifosi_orig .. " follower  (" .. euro(tifosi_orig) .. " euro)")
  L("  scrivo " .. nuovo .. " follower  (" .. euro(nuovo) .. " euro)")
  if scrivi32(b + O_TIFOSI, nuovo) then
    L("  riletto: " .. tostring(u32(b + O_TIFOSI)))
    L("  esci dalla schermata e rientra, poi guarda il contatore Follower")
    L("  e la voce Club di tifosi nel bilancio.")
    tifosi_stato = "SCRITTO " .. nuovo .. " - guarda, poi premi 0"
  else
    tifosi_stato = "la scrittura non ha tenuto"
  end
end

local function tifosi_rimetti()
  if tifosi_orig == nil then tifosi_stato = "niente da rimettere" return end
  local b = api.blocco()
  if not b then return end
  if scrivi32(b + O_TIFOSI, tifosi_orig) then
    L("rimessi " .. tifosi_orig .. " follower")
    tifosi_stato = "RIMESSO " .. tifosi_orig
  else
    tifosi_stato = "non rimesso: chiudi senza salvare"
  end
end


-- ===========================================================================
--  FOTOGRAFIA DI UN RECORD   (tasto 4)
-- ===========================================================================
--
--  Stampa i 380 byte interi di un giocatore. Serve per il confronto
--  PRIMA / DOPO: si fa una foto a inizio stagione, si simulano dieci
--  giornate, se ne fa un'altra, e le caselle che sono cambiate sono le
--  statistiche -- presenze, gol, assist, forma, morale.
--
--  E' molto meglio che cercare i gol: "9" in ventitre' megabyte compare
--  dappertutto e non vuol dire niente. La differenza fra due fotografie
--  dello stesso record invece non puo' mentire.

-- Sette giocatori del Manchester City con statistiche TUTTE DIVERSE dopo
-- dodici giornate. Se una casella contiene 12,12,12,4,12,4,3 sono le
-- presenze; se ne contiene 12,9,5,3,0,0,0 sono i gol. Come abbiamo fatto con
-- le eta': non serve il prima e il dopo, basta il confronto fra giocatori.
--
--                    presenze   gol   assist   voto
--   Haaland             12       12      0      6,3
--   Reijnders           12        9      5      6,0
--   Semenyo             12        5      0      5,9
--   Foden                4        3      2      6,3
--   Doku                12        0      1      5,8
--   Kovacic              4        0      2      5,6
--   Stones               3        0      0      5,5

local FOTO = {
  { nome = "Haaland",   codice = 133543, pres = 12, gol = 12, ass = 0 },
  { nome = "Reijnders", codice = 118274, pres = 12, gol =  9, ass = 5 },
  { nome = "Semenyo",   codice = 124266, pres = 12, gol =  5, ass = 0 },
  { nome = "Foden",     codice = 114808, pres =  4, gol =  3, ass = 2 },
  { nome = "Doku",      codice = 127516, pres = 12, gol =  0, ass = 1 },
  { nome = "Kovacic",   codice =  43135, pres =  4, gol =  0, ass = 2 },
  { nome = "Stones",    codice =  47785, pres =  3, gol =  0, ass = 0 },
}

local function fotografia()
  local base = api.blocco()
  if not base then bilancio_stato = "nessuna Master aperta" return end
  L("")
  L("================================================================")
  L("FOTOGRAFIA DI SETTE GIOCATORI -- caccia alle statistiche")
  L("================================================================")
  for i = 1, #FOTO do
    local f = FOTO[i]
    local r = api.record(f.codice)
    if not r then
      L(f.nome .. ": non trovato")
    else
      local g = api.leggi_giocatore(f.codice)
      L("")
      L("----------------------------------------------------------------")
      L(string.format("%s   presenze %d  gol %d  assist %d", f.nome, f.pres, f.gol, f.ass))
      if g then
        L(string.format("   (eta' %s  overall %s  valore %s)",
          tostring(g.eta), tostring(g.overall), euro(g.valore)))
      end
      L("----------------------------------------------------------------")
      local o = 0
      while o < 380 do
        local q = leggi(r + o, 4)
        local v = u32(r + o)
        if q and v then
          local b1, b2 = string.byte(q,1), string.byte(q,2)
          local b3, b4 = string.byte(q,3), string.byte(q,4)
          local nota = ""
          local function segna(n, etichetta)
            if b1 == n or b2 == n or b3 == n or b4 == n then
              nota = nota .. "  <" .. etichetta .. ">"
            end
          end
          if f.pres > 0 then segna(f.pres, "pres " .. f.pres) end
          if f.gol  > 0 then segna(f.gol,  "gol "  .. f.gol)  end
          if f.ass  > 0 then segna(f.ass,  "ass "  .. f.ass)  end
          L(string.format("  +0x%03X  %12.0f  %3d %3d %3d %3d%s",
            o, v, b1, b2, b3, b4, nota))
        end
        o = o + 4
      end
    end
  end
  L("")
  L("FINE FOTOGRAFIA")
  bilancio_stato = "fotografia dei sette fatta"
end


-- ===========================================================================
--  CACCIA ALLA TABELLA DELLE STATISTICHE   (tasto 3)
-- ===========================================================================
--
--  Le statistiche NON sono nel record da 380 byte: provato il 19 settembre su
--  sette giocatori del City, nessuna delle 95 caselle contiene le presenze,
--  i gol o gli assist. Ha senso: quelle cambiano ogni domenica, il nome no.
--
--  Quindi si cerca una SEQUENZA invece di un numero. "12" da solo in ventitre'
--  megabyte compare dappertutto; "12, 9, 5" di fila molto meno.
--
--  Proviamo le tre larghezze possibili: un byte, due byte, quattro byte.

-- Le prestazioni del Galatasaray, prese dai "Risultati generali" il 19
-- settembre. Il Galatasaray ha giocato 13 partite (Cakir, il portiere, ne
-- ha 13). Quindi se anche loro hanno un gruppo come il nostro, deve esserci
-- da qualche parte la sequenza a 16 bit:
--
--     13, presenze, gol, assist
--
-- Gli ultimi due sono i nostri, e servono da controllo: quelli SAPPIAMO
-- dove stanno, e se la ricerca non li trova vuol dire che e' rotta lei.

-- ===========================================================================
--  DOVE COMPARE UN GIOCATORE DEL GALATASARAY   (tasto 3)
-- ===========================================================================
--
--  Due ricerche a vuoto: ne' "13, presenze, gol, assist" ne' la quaterna
--  "presenze, gol, assist, presenze". I controlli del City (Cherki 8-1-7 e
--  Reijnders 12-9-5) li trova sempre tutti e due, quindi lo strumento e'
--  sano: quei numeri, in quella forma, nel blocco non ci sono.
--
--  Allora smetto di indovinare la forma del record. Il CODICE del giocatore
--  nel blocco c'e' -- Osimhen compare tredici volte. Stampo cosa c'e'
--  attorno a ognuna di quelle volte e la forma me la dice la memoria.
--
--  E' la stessa mossa che ha risolto la tabella del City: la caccia aveva
--  dato la zona, ma la struttura si e' letta solo guardando i byte in
--  chiaro.

local CHI_GUARDO = {
  { nome = "Osimhen  (11-4-0)",  codice = 126895 },
  { nome = "Gundogan (9-4-5)",   codice =  45945 },
  { nome = "Sane     (8-3-1)",   codice = 102901 },
  { nome = "Cherki   (8-1-7) CITY, controllo", codice = 133653 },
}

local function caccia_statistiche()
  local base = api.blocco()
  if not base then bilancio_stato = "nessuna Master aperta" return end

  L("")
  L("================================================================")
  L("DOVE COMPARE IL CODICE, E COSA C'E' ATTORNO")
  L("================================================================")

  for i = 1, #CHI_GUARDO do
    local g = CHI_GUARDO[i]
    local pat = memory.pack("u32", g.codice)
    local hit = {}
    local pos = FINE_TAB
    while pos < FINESTRA do
      local quanti = 0x10000
      local extra  = 3
      if pos + quanti > FINESTRA then quanti = FINESTRA - pos; extra = 0 end
      local dati = leggi(base + pos, quanti + extra)
      if dati then
        local da = 1
        while #hit < 24 do
          local a = string.find(dati, pat, da, true)
          if not a then break end
          local off = pos + a - 1
          if off < FINESTRA then hit[#hit + 1] = off end
          da = a + 1
        end
      end
      pos = pos + 0x10000
    end

    L("")
    L("################################################################")
    L(string.format("%s   codice %d   ->  %d volte fuori dalla tabella grande",
      g.nome, g.codice, #hit))
    L("################################################################")

    for j = 1, #hit do
      local o = hit[j]
      if o >= 32 and o + 64 <= FINESTRA then
        L("")
        L(string.format("--- +0x%08X ---", o))
        local q = leggi(base + o - 32, 96)
        if q then
          local riga = ""
          for k = 1, 96 do
            riga = riga .. string.format("%02X ", string.byte(q, k))
            if k % 16 == 0 then
              L(string.format("  %+4d  %s", (k - 16) - 32, riga))
              riga = ""
            end
          end
        end
      end
    end
  end

  L("")
  L("FINE")
  bilancio_stato = "vicinati stampati"
end

-- ===========================================================================
--  ALLINEAMENTO DELLA TABELLA DELLE STATISTICHE   (tasto 2)
-- ===========================================================================
--
--  Il 19 settembre il tasto 3 ha trovato la zona: tutti i giocatori del City
--  hanno le loro presenze-gol-assist scritte a 16 bit dentro
--
--        blocco + 0x1675xxx
--
--  e ognuno compare due volte a 0x18 byte di distanza. Adesso servono tre
--  cose che il tasto 3 non puo' dare:
--
--    1. QUANTO E' LUNGO UN RECORD. Si vede solo guardando molti giocatori di
--       fila e misurando le distanze.
--    2. DI CHI E' UNA RIGA. Nei 24 byte il codice del giocatore non c'e'.
--       L'ipotesi e' che la tabella sia ordinata come quella dei giocatori,
--       cioe' che la riga numero N sia del giocatore che nella tabella grande
--       ha indice N (la casella a +0x02C). Se e' cosi', la distanza fra due
--       righe diviso il passo deve dare la differenza fra i due indici.
--    3. DOVE COMINCIA E DOVE FINISCE.
--
--  Quindi: si cercano tutti e sette i giocatori della fotografia, ma solo
--  dentro 64 kB attorno alla zona -- cosi' anche le terne banali come 4-0-2
--  danno pochi risultati e li vedo tutti. Poi si stampa la zona in chiaro.
--
--  La zona sta dentro FINESTRA, quindi non si esce dalla memoria mappata.

-- ===========================================================================
--  LA ROSA E LE SUE PRESTAZIONI   (tasto 2)
-- ===========================================================================
--
--  Adesso la tabella la trova il motore da solo, con api.rosa(). Questo
--  tasto serve a controllare che la trovi davvero, in qualunque carriera:
--  se i nomi e i numeri che stampa sono quelli che hai a video, il motore
--  e' a posto e i moduli ci si possono appoggiare.

local function la_rosa()
  local base = api.blocco()
  if not base then bilancio_stato = "nessuna Master aperta" return end

  local o = api.tabella_rosa()
  if not o then
    L("")
    L("la tabella delle prestazioni non si trova")
    bilancio_stato = "tabella prestazioni non trovata"
    return
  end

  local r = api.rosa()
  L("")
  L("================================================================")
  L(string.format("LA ROSA -- tabella trovata a +0x%08X", o))
  L("================================================================")
  L("  #  indice  codice  nome              pres  gol  ass  voto   valore")
  L("----------------------------------------------------------------")
  for i = 1, #r do
    local g = r[i]
    local nome, val, eta, ov = "?", nil, "?", "?"
    local rec = api.record(g.codice)
    if rec then
      nome = api.nome(rec) or "?"
      local d = api.leggi_giocatore(g.codice)
      if d then val = d.valore; eta = d.eta; ov = d.overall end
    end
    local voto = 0
    if g.presenze > 0 then voto = g.voti / g.presenze / 10 end
    L(string.format(" %2d  %6d  %6d  %-16s  %4d %4d %4d  %4.2f   %s  (%s anni, ov %s)",
      i, g.indice, g.codice, string.sub(nome, 1, 16),
      g.presenze, g.gol, g.assist, voto, euro(val), tostring(eta), tostring(ov)))
  end
  L("----------------------------------------------------------------")
  L(string.format("%d giocatori, %d partite giocate dalla squadra",
    #r, (r[1] and r[1].partite_squadra) or 0))
  L("")
  L("FINE")
  bilancio_stato = "rosa letta: " .. #r .. " giocatori"
end

function m.key_down(ctx, vkey)
  if os.clock() - ultimo_overlay > 0.2 then return end
  local ospite = tasti_ospiti[vkey]
  if ospite then ospite.fn() return end
  if vkey == 0x32 or vkey == 0x62 then la_rosa() end
  if vkey == 0x33 or vkey == 0x63 then caccia_statistiche() end
  if vkey == 0x34 or vkey == 0x64 then fotografia() end
  if vkey == 0x35 or vkey == 0x65 then prova_scrivi() end
  if vkey == 0x36 or vkey == 0x66 then prova_rimetti() end
  if vkey == 0x37 or vkey == 0x67 then cerca_bilancio() end
  if vkey == 0x38 or vkey == 0x68 then dump_bilancio() end
  if vkey == 0x39 or vkey == 0x69 then tifosi_scrivi() end
  if vkey == 0x30 or vkey == 0x60 then tifosi_rimetti() end
end

local function ospiti_a_video()
  local r = {}
  for _, o in pairs(tasti_ospiti) do
    r[#r+1] = "[" .. o.etichetta .. "] " .. o.descrizione
  end
  if #r == 0 then return "" end
  return "\n\ndagli altri moduli:\n" .. table.concat(r, "\n")
end

function m.overlay_on(ctx)
  ultimo_overlay = os.clock()
  local righe = {}
  righe[#righe+1] = "aggancio : " .. diagnosi
  local b = api.blocco()
  if not b then
    righe[#righe+1] = "blocco   : nessuna Master aperta (entra e gira un po')"
  else
    righe[#righe+1] = "blocco   : " .. memory.hex(b)
    local g, me, an = api.data()
    righe[#righe+1] = string.format("data     : %s/%s/%s", tostring(g), tostring(me), tostring(an))
    local bt, bi = api.budget()
    righe[#righe+1] = "budget   : " .. euro(bt) .. "  /  " .. euro(bi)
    local tf = u32(b + 0x016ECC28)
    righe[#righe+1] = "tifosi   : " .. tostring(tf) .. "  (= " .. euro(tf) .. " euro)"
    local p = api.leggi_giocatore(CAMPIONE)
    if p then
      righe[#righe+1] = ""
      righe[#righe+1] = "prova di lettura -- " .. p.nome
      righe[#righe+1] = string.format("  eta' %s   overall %s   indice %s",
        tostring(p.eta), tostring(p.overall), tostring(p.indice))
      righe[#righe+1] = "  valore    " .. euro(p.valore)
      righe[#righe+1] = "  stipendio " .. euro(p.stipendio)
      righe[#righe+1] = string.format("  contratto %s/%s/%s",
        tostring(p.contratto_giorno), tostring(p.contratto_mese), tostring(p.contratto_anno))
    else
      righe[#righe+1] = NOME_CAMPIONE .. " non trovato in questa carriera"
    end
  end
  local pv = api.leggi_giocatore(PROVA_CODICE)
  righe[#righe+1] = ""
  righe[#righe+1] = "PROVA -- " .. PROVA_NOME .. "   valore ora: "
                 .. euro(pv and pv.valore)
  righe[#righe+1] = "  " .. prova_stato
  return "ECONOMIA LUNGA v" .. m.versione .. "  -  motore\n"
      .. "--------------------------------------------------\n"
      .. table.concat(righe, "\n") .. "\n\n"
      .. "[2] tabella prestazioni       [3] dove compare il codice\n"
      .. "[4] fotografia dei sette\n"
      .. "[5] valore x" .. PROVA_FATT .. "     [6] rimetti quello vero\n"
      .. "[7] ricerca    [8] leggi la finestra del bilancio\n"
      .. "    " .. bilancio_stato .. "\n\n"
      .. "[9] tifosi x" .. TIFOSI_FAT .. "     [0] rimetti i tifosi veri\n"
      .. "    " .. tifosi_stato .. ospiti_a_video()
end

-- v1.19: le funzioni agganciate agli eventi stanno DENTRO la tabella del
-- modulo, cosi' restano vive per tutta la partita (vedi sopra)
function m.set_teams(ctx) fai_giri() end
function m.after_set_conditions(ctx) fai_giri() end
function m.get_stadium_name(ctx, a, b, c) fai_giri(); return nil end
local ultimo_file = -100
function m.make_key(ctx, filename)
  local t = os.clock()
  if t - ultimo_file >= 2 then
    ultimo_file = t
    fai_giri()
  end
  return nil
end

function m.init(ctx)
  L("Economia Lunga v" .. m.versione .. " - motore")
  if prepara() then
    L(diagnosi)
    if nostro_aggancio then
      L("da questo momento BudgetSetter non trovera' piu' la sua firma e")
      L("restera' spento da solo: e' normale, non serve piu'.")
    end
  else
    L("NON PARTITO: " .. diagnosi)
  end
  ctx.economia = api
  ctx.register("key_down", m.key_down)
  ctx.register("overlay_on", m.overlay_on)
  ctx.register("set_teams", m.set_teams)
  ctx.register("after_set_conditions", m.after_set_conditions)
  ctx.register("get_stadium_name", m.get_stadium_name)
  ctx.register("livecpk_make_key", m.make_key)   -- v1.21
end

return m
