FL26 Master League Realism Mods by Michele & Claude (Anthropic AI).
Included in The Gaffer with their permission. Credit: "Michele & Claude". Grazie mille!

Installed from Setup:
  FL26 - Guardia rosa vuota.lua   fixes the 1 July "division by zero" crash (must be the FIRST lua.module)
  Economia Lunga - motore.lua     engine needed by the rules module (before it in sider.ini)
  Regole di tesseramento.lua      real squad registration rules (list of 25, non-EU limits) for you and the CPU
The modules check the original game bytes first: on a different FL_2026.exe build they change nothing and write the reason in sider.log.
