-- PlayerDump.lua (Karijera 26)
-- How to use: in game press Space (Sider overlay), switch modules with 1 until "PlayerDump" is shown, press F7.
-- Finds the player table in memory and writes it to content\ml-immersion\bridge\players_dump.bin (+ .meta and .log).
-- It only READS memory; nothing in the game is changed.
local m = { version = "2.4" }

-- Sider nema pcall: nadomjestak preko xpcall ili coroutine
local pcall = pcall
if not pcall then
    if xpcall then
        pcall = function(f, ...)
            local a = { ... }
            return xpcall(function() return f(unpack and unpack(a) or table.unpack(a)) end, function(e) return e end)
        end
    elseif coroutine and coroutine.create then
        pcall = function(f, ...)
            local co = coroutine.create(f)
            local r = { coroutine.resume(co, ...) }
            return unpack and unpack(r) or table.unpack(r)
        end
    else
        pcall = function(f, ...) return true, f(...) end
    end
end

local KEY_F7 = 0x76
local BLOCK = 0x17C
local OUT_DIR = "content\\ml-immersion\\bridge\\"
-- 1.7: the game stores short names ("E. Haaland"), so the old full-name seeds never matched
-- FL26: kratko ime ("E. Haaland"); Football Life 2027: puno ime ("Erling Haaland") na istom mjestu u bloku (+0x38, id na +0x30)
-- 2.4: i klasicni patchevi (Redoux 2006, Dream Patch...): u bazi iz 2006. nema Haalanda ni Salaha, pa tablica nije nadjena
--      (FAILED kod korisnika s Reddita). Dodani igraci koji postoje u starijim bazama (kratko i puno ime).
local SEEDS = { "E. Haaland", "G. Donnarumma", "J. Gvardiol", "M. Salah", "V. van Dijk", "K. Mbapp", "Erling Haaland", "Virgil van Dijk", "Mohamed Salah", "Gianluigi Donnarumma",
    "L. Messi", "Lionel Messi", "Cristiano Ronaldo", "Ronaldinho", "T. Henry", "Thierry Henry", "Z. Zidane", "Zinedine Zidane", "A. Shevchenko", "Andriy Shevchenko",
    "F. Totti", "Francesco Totti", "G. Buffon", "Gianluigi Buffon", "A. Pirlo", "Andrea Pirlo", "S. Gerrard", "Steven Gerrard", "F. Lampard", "Frank Lampard" }

local ctx_ref
local data_addr = nil
local last_msg, last_msg_time = "PlayerDump: F7 = dump players for the app", 0

local function out_path(name) return ctx_ref.sider_dir .. OUT_DIR .. name end

local AUTO_DUMP = false   -- iskljuceno: moguci uzrok rusenja pri spremanju
local quiet = false
local last_auto = -100
local function log(s)
    if quiet and not (s:find("^FAILED") or s:find("^ERROR")) then last_msg = s; return end
    -- 2.3: tehnicki koraci ("step A/B/C/D/E", "F7/F8 pressed") se ne prikazuju u overlayu: prije je "step C: ok=true err=nil"
    --      prekrio poruku DONE / FAILED, pa korisnik nije znao je li dump uspio
    if not s:find("^key") and not s:find("^step ") and not s:find("^F7/F8 pressed") then last_msg = s; last_msg_time = os.clock() end
    local f = io.open(out_path("players_dump.log"), "a")
    if f then f:write(os.date("%Y-%m-%d %H:%M:%S  ") .. s .. "\n"); f:close() end
end

-- 1.5: sigurno citanje preko ReadProcessMemory (LuaJIT ffi). Neispravna/nemapirana adresa vrati nil umjesto da sruši igru
-- (memory.read na losoj adresi je access violation u sider.dll; pcall to ne hvata). Bez ffi ostaje staro citanje.
local RPM = nil
local REGIONS = nil
local BASE_TBL, BASE_DONE = nil, false   -- 2.1: osnovna tablica igraca (atributi iz baze igre) -> players_base.bin, jednom po pokretanju
local LAST = nil   -- 2.2: {first, stride} zadnje tablice karijere; pred utakmicu se prvo provjeri ona (brzo, bez skeniranja)
local LIVE_TABLE = true   -- 1.9: false = nadjena samo osnovna tablica (bez morala/OVR-a)
do
    -- 1.6: Sider has no 'require' (and no real pcall): 1.5 stopped loading there. LuaJIT ffi is the global 'ffi'
    -- when luajit.ext.enabled = 1; require only if it exists.
    local ffi = ffi
    if ffi == nil and type(require) == "function" then
        local okr, r = pcall(require, "ffi")
        if okr then ffi = r end
    end
    if type(ffi) == "table" or type(ffi) == "userdata" then
        pcall(ffi.cdef, [[
            void* PD_GetCurrentProcess(void) __asm__("GetCurrentProcess");
            int PD_ReadProcessMemory(void* hProcess, const void* lpBaseAddress, void* lpBuffer, size_t nSize, size_t* lpNumberOfBytesRead) __asm__("ReadProcessMemory");
        ]])
        local okp, proc = pcall(function() return ffi.C.PD_GetCurrentProcess() end)
        if okp and proc then
            pcall(ffi.cdef, [[
                typedef struct { void* BaseAddress; void* AllocationBase; uint32_t AllocationProtect; uint16_t PartitionId;
                                 size_t RegionSize; uint32_t State; uint32_t Protect; uint32_t Type; } PD_MBI;
                size_t PD_VirtualQuery(const void* lpAddress, PD_MBI* lpBuffer, size_t dwLength) __asm__("VirtualQuery");
            ]])
            local okm, mbi = pcall(ffi.new, "PD_MBI[1]")
            if okm and mbi then
                -- 1.7: list of committed read/write regions (start, size), for the memory scan fallback
                REGIONS = function(min_size)
                    local out, addr = {}, 0x10000
                    local sz = ffi.sizeof("PD_MBI")
                    while addr < 0x7FFFFFFF0000 and #out < 20000 do
                        local r = ffi.C.PD_VirtualQuery(ffi.cast("const void*", addr), mbi, sz)
                        if r == 0 then break end
                        local b = tonumber(ffi.cast("uintptr_t", mbi[0].BaseAddress))
                        local n = tonumber(mbi[0].RegionSize)
                        if not n or n <= 0 then break end
                        local pr = mbi[0].Protect
                        if mbi[0].State == 0x1000 and (pr == 0x04 or pr == 0x08 or pr == 0x40) and n >= min_size then
                            out[#out + 1] = { b, n }
                        end
                        addr = b + n
                    end
                    return out
                end
            end
            local cap = 0x10000
            local buf = ffi.new("uint8_t[?]", cap)
            local got = ffi.new("size_t[1]")
            RPM = function(addr, len)
                if type(addr) ~= "number" or addr < 0x10000 or len <= 0 or len > 0x4000000 then return nil end
                if len > cap then cap = len; buf = ffi.new("uint8_t[?]", cap) end
                got[0] = 0
                local r = ffi.C.PD_ReadProcessMemory(proc, ffi.cast("const void*", addr), buf, len, got)
                if r == 0 or tonumber(got[0]) ~= len then return nil end
                return ffi.string(buf, len)
            end
        end
    end
end

local function safe_read(addr, len)
    if RPM then return RPM(addr, len) end
    local ok, res = pcall(memory.read, addr, len)
    if ok and res and #res == len then return res end
    return nil
end

local function u32(s, off)
    return memory.unpack("u32", s:sub(off + 1, off + 4))
end

local function valid(addr)
    local blk = safe_read(addr + 0x30, 0x20)
    if not blk then return false end
    local id = u32(blk, 0)
    if id < 1 or id > 400000 then return false end
    local c = blk:byte(9)           -- prvi znak imena (+0x38)
    if not c or c < 0x20 then return false end
    return true
end

local function detect_stride(base)
    if valid(base + 0x17C) and valid(base + 2 * 0x17C) and valid(base + 3 * 0x17C) then return 0x17C end
    for s = 0x100, 0x400, 4 do
        if valid(base + s) and valid(base + 2 * s) and valid(base + 3 * s) then return s end
    end
    return nil
end

local function u64(s, off)
    return memory.unpack("u64", s:sub(off + 1, off + 8))
end

local function morale_ok(first, stride, n)
    local tot, live, k = 0, 0, 0
    while k < (n or 3000) do
        local d = safe_read(first + k * stride + 0x13E, 2)
        if not d then break end
        tot = tot + 1
        if math.floor((d:byte(1) + d:byte(2) * 256) / 4) % 128 ~= 0 then live = live + 1 end
        k = k + 5
    end
    return tot > 20 and live >= tot * 0.3
end

local function find_base()
    -- 2.2: same table as the last dump (same loaded save): no memory scan needed
    if LAST and valid(LAST[1]) and valid(LAST[1] + LAST[2]) and morale_ok(LAST[1], LAST[2], 3000) then
        LIVE_TABLE = true
        return LAST[1], LAST[2], "last table", LAST[1] + 0x38
    end
    log("step E: find_base")
    -- 1) pokazivac na zadnjeg igraca kojeg je igra dotaknula (nas vlastiti hook, isti kao StatEditor)
    if not data_addr then
        log("hook not installed (init could not install it)")
    else
        local pb = safe_read(data_addr, 8)
        local ptr = pb and tonumber(u64(pb, 0)) or 0
        log(string.format("captured player pointer: 0x%X", ptr))
        if ptr > 0x10000 and valid(ptr) then
            local s = detect_stride(ptr)
            if s then return ptr, s, "hook-pointer", ptr end
            log("pointer valid, stride not found")
        else
            log("pointer is not a valid block yet: open Player Info for any player (browse players), then F7")
        end
    end
    -- 2) trazenje imena
    for _, name in ipairs(SEEDS) do
        local ok, addr = pcall(memory.search_process, name)
        log("searching '" .. name .. "': " .. tostring(ok) .. " " .. (addr and string.format("0x%X", addr) or "nil"))
        local tries = 0
        while ok and addr and tries < 12 do
            tries = tries + 1
            local base = addr - 0x38
            if valid(base) then
                local s = detect_stride(base)
                if s then return base, s, name, addr end
                log(string.format("candidate %s @0x%X: block valid, stride not found", name, addr))
            end
            local ok2, nxt = pcall(memory.search_process, name, addr + 1)
            if not ok2 or not nxt or nxt == addr then break end
            addr = nxt
        end
    end
    -- 3) 1.7: scan the game's own memory (heap) for a short name, then check the block around it.
    --    Needed when the hook never fires (e.g. classic 19.9 MB setup without the Mod Studio modules).
    if REGIONS and RPM then
        local regs = REGIONS(0x100000)
        log(string.format("memory scan: %d regions", #regs))
        local CH = 0x400000
        for _, name in ipairs(SEEDS) do
            local pat = name .. "\0"
            local cands = {}
            for _, rg in ipairs(regs) do
                local off = 0
                while off < rg[2] do
                    local len = math.min(CH + 64, rg[2] - off)
                    local chunk = RPM(rg[1] + off, len)
                    if chunk then
                        local i = 1
                        while true do
                            local h = string.find(chunk, pat, i, true)
                            if not h then break end
                            local base = rg[1] + off + h - 1 - 0x38
                            if #cands < 8 and valid(base) then
                                local st = detect_stride(base)
                                if st then cands[#cands + 1] = { base, st } end
                            end
                            i = h + 1
                        end
                    end
                    off = off + CH
                end
            end
            -- several copies of the player table can exist (database + career): take the biggest one
            -- 1.8: the live career table has morale (+0x13E) filled in; the other copy has zeros there.
            --      Take the table with the most non-zero morale bytes; on a tie the bigger one. Each copy is also
            --      written to players_cand<N>.bin so the app author can compare them.
            local best, best_key, seen, best_live = nil, nil, {}, 0
            for ci, c in ipairs(cands) do
                local a, n = c[1], 0
                while n < 70000 and valid(a - c[2]) do a = a - c[2]; n = n + 1 end
                if not seen[a] then
                    seen[a] = true
                    local cnt, b = 0, a
                    while cnt < 70000 and valid(b) do b = b + c[2]; cnt = cnt + 1 end
                    local live = 0
                    for k = 0, math.min(cnt, 4000) - 1 do
                        local x = RPM(a + k * c[2] + 0x13E, 1)
                        if x and x:byte(1) ~= 0 then live = live + 1 end
                    end
                    log(string.format("memory scan: '%s' table @0x%X, %d players, morale set on %d", name, a, cnt, live))
                    local key = live * 100000 + cnt
                    if not best_key or key > best_key then best, best_key, best_live = { a, c[2] }, key, live end
                    if live == 0 and (not BASE_TBL or cnt > BASE_TBL[3]) then BASE_TBL = { a, c[2], cnt } end
                end
            end
            if best then
                if data_addr then pcall(memory.write, data_addr, memory.pack("u64", best[1])) end
                LIVE_TABLE = best_live > 0
                return best[1], best[2], "scan:" .. name, best[1] + 0x38
            end
        end
        log("memory scan: nothing found")
    else
        log("memory scan not available (no ffi)")
    end
    return nil
end

local function hexdump(s, n)
    local t = {}
    for i = 1, math.min(n, #s) do t[#t + 1] = string.format("%02x", s:byte(i)) end
    return table.concat(t, " ")
end

local function window_dump(center)
    local W = 0x100000
    local start = center - W
    start = start - (start % 0x1000)
    local parts, ok_pages = {}, 0
    for p = 0, (2 * W) / 0x1000 - 1 do
        local pg = safe_read(start + p * 0x1000, 0x1000)
        if pg then ok_pages = ok_pages + 1; parts[#parts + 1] = pg else parts[#parts + 1] = string.rep("\0", 0x1000) end
    end
    local f = io.open(out_path("players_window.bin"), "wb")
    if f then f:write(table.concat(parts)); f:close() end
    local mf = io.open(out_path("players_window.meta"), "w")
    if mf then mf:write(string.format("start=0x%X\ncenter=0x%X\npages_ok=%d\n", start, center, ok_pages)); mf:close() end
    log(string.format("window around pointer written: start=0x%X, readable pages %d", start, ok_pages))
end

function m.dump()
    log("step D: entering dump")
    local t0 = os.clock()
    log("searching for the player table...")
    LIVE_TABLE = true
    local base, stride, name, found = find_base()
    if not base then
        log("FAILED: player table not found (open your career / a menu with players and try again)")
        return
    end
    -- prosiri unatrag i unaprijed
    local first = base
    local n = 0
    while n < 70000 and valid(first - stride) do first = first - stride; n = n + 1 end
    local count = 0
    local a = first
    while count < 70000 and valid(a) do a = a + stride; count = count + 1 end
    log(string.format("table: seed '%s' @0x%X, stride 0x%X, blocks %d, first @0x%X", name, found, stride, count, first))

    local parts, CH = {}, 64
    local i = 0
    local bad = 0
    while i < count do
        local c = math.min(CH, count - i)
        local chunk = safe_read(first + i * stride, c * stride)
        if chunk then
            for k = 0, c - 1 do parts[#parts + 1] = chunk:sub(k * stride + 1, k * stride + BLOCK) end
        else
            for k = 0, c - 1 do
                local b = safe_read(first + (i + k) * stride, BLOCK)
                if b then parts[#parts + 1] = b else bad = bad + 1; parts[#parts + 1] = string.rep("\0", BLOCK) end
            end
        end
        i = i + c
    end
    local f = io.open(out_path("players_dump.bin"), "wb")
    if not f then log("FAILED: cannot write players_dump.bin"); return end
    f:write(table.concat(parts)); f:close()
    if LIVE_TABLE then LAST = { first, stride } end
    -- 2.1: the base copy of the player table (database attributes, before career growth). The app uses it to work out
    --      the live overall on Football Life 2027, where the stored overall (+0x179) does not change when attributes grow.
    if BASE_TBL and not BASE_DONE and BASE_TBL[1] ~= first then
        local bp, bi, bst, bcnt = {}, 0, BASE_TBL[2], BASE_TBL[3]
        while bi < bcnt do
            local c = math.min(CH, bcnt - bi)
            local chunk = safe_read(BASE_TBL[1] + bi * bst, c * bst)
            for k = 0, c - 1 do
                if chunk then bp[#bp + 1] = chunk:sub(k * bst + 1, k * bst + BLOCK) else bp[#bp + 1] = string.rep("\0", BLOCK) end
            end
            bi = bi + c
        end
        local bf = io.open(out_path("players_base.bin"), "wb")
        if bf then bf:write(table.concat(bp)); bf:close(); BASE_DONE = true; log(string.format("base table written: %d players", bcnt)) end
    end

    local mf = io.open(out_path("players_dump.meta"), "w")
    if mf then
        mf:write(string.format("stride=0x%X\nblock=0x%X\ncount=%d\nfirst_addr=0x%X\nseed=%s\nbad_reads=%d\nwritten=%d\n", stride, BLOCK, count, first, name, bad, os.time()))
        mf:write(string.format("live=%d\n", LIVE_TABLE and 1 or 0))
        local seed_blk = safe_read(base, BLOCK)
        if seed_blk then mf:write("seed_block=" .. hexdump(seed_blk, BLOCK) .. "\n") end
        local after = safe_read(base + BLOCK, math.max(0, math.min(0x200, stride - BLOCK)))
        if after and #after > 0 then mf:write("after_block=" .. hexdump(after, #after) .. "\n") end
        mf:close()
    end
    if LIVE_TABLE then
        log(string.format("DONE: %d players written in %.1f s (bad reads: %d) - the app can read them now", count, os.clock() - t0, bad))
    else
        log(string.format("DONE (%d players), but WITHOUT morale/overall: go to Team Management and press F7 again", count))
    end
end

local keys_logged = 0
function m.key_down(ctx, vkey)
    if keys_logged < 25 then
        keys_logged = keys_logged + 1
        log(string.format("key 0x%X", vkey))
    end
    if tonumber(vkey) == KEY_F7 or tonumber(vkey) == 0x77 then
        log("F7/F8 pressed, starting dump (type m.dump=" .. type(m.dump) .. ", memory=" .. type(memory) .. ")")
        log("step A: pcall=" .. type(pcall) .. " xpcall=" .. type(xpcall) .. " coroutine=" .. type(coroutine) .. " unpack=" .. type(unpack) .. " table.unpack=" .. type(table and table.unpack))
        local ok, err = pcall(function()
            log("step B: inside pcall")
            m.dump()
        end)
        log("step C: ok=" .. tostring(ok) .. " err=" .. tostring(err))
    end
end

-- 2.2: automatic F7 before every match you play (Sider "set_teams"): the app gets fresh players and GrowthBridge the
--      current table address, so nobody has to open the overlay. Same table as last time = a quick re-read (no scan).
function m.set_teams(ctx, home, away)
    local ok, err = pcall(function()
        quiet = true
        m.dump()
        quiet = false
    end)
    quiet = false
    last_msg = ok and ("auto F7 before the match " .. os.date("%H:%M:%S")) or ("auto F7 failed: " .. tostring(err))
    log(last_msg)
end

function m.overlay_on(ctx)
    if AUTO_DUMP and os.clock() - last_auto >= 20 and data_addr then
        last_auto = os.clock()
        local pb = safe_read(data_addr, 8)
        local ptr = pb and tonumber(u64(pb, 0)) or 0
        if ptr > 0x10000 and valid(ptr) then
            quiet = true
            m.dump()
            quiet = false
            last_msg = string.format("auto-dump %s", os.date("%H:%M:%S"))
        end
    end
    local info = "hook=" .. (data_addr and "ok" or "not found")
    if data_addr then
        local pb = safe_read(data_addr, 8)
        if pb then info = info .. string.format(" ptr=0x%X", tonumber(u64(pb, 0))) end
    end
    return string.format(" PlayerDump v%s  [F7]  %s\n %s", m.version, info, last_msg)
end

local function install_hook()
    local aob1 = "\x48\x8B\x40\x2C\x48\x89\x02\x48\x89\xD0\xC3"
    local aob2 = "\x48\x8B\x40\x2C\x48\x89\x02\x48\x8B\xC2\xC3"
    local h = memory.search_process(aob1) or memory.search_process(aob2)
    if not h then log("hook: AOB not found (StatEditor may have patched it already; restart the game)"); return end
    local cave = memory.allocate_codecave(128)
    data_addr = cave + 0x50
    memory.write(data_addr, memory.pack("u64", 0))
    local stolen = memory.read(h, 10)
    local code = "\x48\x89\x05" .. memory.pack("i32", 0x50 - 7)
    code = code .. stolen
    code = code .. "\xFF\x25\x00\x00\x00\x00" .. memory.pack("u64", h + 14)
    memory.write(cave, code)
    memory.write(h, "\xFF\x25\x00\x00\x00\x00" .. memory.pack("u64", cave) .. "\xC3")
    log("hook installed, pointer is kept in a code cave")
end

function m.init(ctx)
    ctx_ref = ctx
    install_hook()
    -- 1.6: share the hook pointer with other modules (Injuries For All finds the career player table with it):
    -- ctx.gaffer_player_ptr = address of a u64 that holds the last player record the game touched
    ctx.gaffer_player_ptr = data_addr
    ctx.register("key_down", m.key_down)
    ctx.register("overlay_on", m.overlay_on)
    ctx.register("set_teams", m.set_teams)
    log("PlayerDump loaded")
end

return m
